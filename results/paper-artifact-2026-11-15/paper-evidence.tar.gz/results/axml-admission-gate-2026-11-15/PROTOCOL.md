# Structure-checked descendants and device admission gate — protocol

Written 2026-11-15 after the code changes and regression suite, before the AFL
run. Authorized by the user in chat ("Start step B"). Local F-Droid corpus APK
and local offline Android 29 emulator only. No model call, no VM, no network-
facing test. Historical runs, the two 72-hour arm definitions, and all
previously built mutator binaries are unchanged.

## Change under test

- New locked variant `manifest-axml-onebit`: `manifest-valid-onebit` plus a
  structural binary-XML check on the decoded manifest, applied to the parent
  before mutation (failing descendants restart from the origin) and to every
  accepted output.
- Offline gates reject any `aapt` resource-parser warning and any manifest
  failing the same structure check.
- Device gate: `launched_process_running` now needs a running process, no
  fatal exception for the package since the probe began, and the baseline's
  resolved activity. LLMDroid admission requires that result.

## Question and hypotheses

Does the change let live later-generation mutants reach a healthy launch?

- **H4.** At least one live generation-two (or later) mutant from the new mode
  passes the offline gate *and* the device gate. In the 2026-11-12 diagnostic
  (old mode, seed 10434), 30 generation-two mutants passed the offline gate,
  2 installed, and none had a running process. *Falsified* if no later-
  generation mutant passes the device gate.
- **H5.** The stricter offline gate is a better predictor than the old one:
  the share of offline-ready mutants that pass the device gate exceeds the
  22/38 seen for generation one under the old gate. Descriptive only.

## Fixed design

- AFL: `python3 -B scripts/run-fdroid-local-sampled-arm.py 120 10435 <out>
  --mode manifest-axml-onebit --gen1-first 0 --gen1-rate 1000
  --descendant-rate 50 --max-capture-bytes 2000000000` — the same duration and
  sampling as seed 10434. The mode and the AFL seed both differ from that run,
  so the comparison is confounded by which mutants AFL happens to queue; this
  is recorded, not corrected.
- Device cohort: every later-generation mutant the live analysis marks
  `ready_for_install_attempt`, in iteration order, at most 40. Baseline probed
  first, in the middle, and last. Gate controls probed before the cohort: the
  known-healthy mutant (run 10432 iteration 1) must be
  `launched_process_running`, and the known start-up crasher (run 10433
  iteration 15) must be `launched_crashed`.
- Queue path: each captured queue entry goes through the unchanged-interface
  tools (`prepare-manifest-runtime-candidate.py`, `probe-android-runtime.py`
  with `--baseline-probe-report`, `llmdroid-analysis-queue.py plan` with
  `--device-report`).
- Replay: eight-action signed-baseline trace `3d3edc9f…43e9`; an
  original/original control, then one admitted later-generation pair if any
  exists (`run-llmdroid-pair.py --timeout-per-run 240 --interval 2`).
- Emulator: AVD `apkfuzz_fdroid29`, port 5562, `-no-snapshot -wipe-data`,
  Wi-Fi and mobile data disabled.

## Stop conditions and limits

Stop and report inconclusive infrastructure if: the AFL runner, watcher, or
analyzer exits nonzero or reports source/input drift; the emulator does not
boot in 300 s; a baseline probe is not `launched_process_running`; either gate
control gives the wrong class; a probe reports the device unavailable or a
crash check failure; or cleanup is incomplete. Limits: 120 s of AFL, 2 GB of
captures, 50 device probes, two paired replays, one emulator shut down and
verified at the end.

## Interpretation limits

AFL feedback is still Python-harness coverage. Install failures and start-up
crashes of mutated manifests are expected effects of the mutation, not F-Droid
defects. A replay divergence would be a defect *candidate* requiring
reproduction; an infrastructure fault is inconclusive.
