# Structure-checked descendants and device admission gate — 2026-11-15

## Conclusion

With the new opt-in `manifest-axml-onebit` mode and tightened gates, **28 of 40
live generation-two mutants launched F-Droid's `MainActivity` with no crash**
on a fresh offline Android 29 emulator. In the 2026-11-12 diagnostic with the
older mode, 30 generation-two mutants passed the offline gate, 2 installed,
and none had a running process. An original/original replay control and one
admitted generation-two pair each completed all eight trace actions with no
divergence observed. Both pre-registered hypotheses in [PROTOCOL.md](PROTOCOL.md)
are supported, with the confounders listed below.

This clears the specific blocker behind the 12 November no-go: later-generation
mutants can now reach Android. It does **not** by itself justify a 12-hour
run; see "What this does not show".

## Authorization, scope, environment

Authorized by the user in chat on 2026-11-15 ("Start step B"). Local F-Droid
corpus APK and local offline emulator only. No model call, VM, or network-
facing test. Git HEAD `96f82a05f0376d4f79b897b72f6a6d17d907143d` plus the
pre-existing uncommitted work plus the changes below; nothing committed.

Linux 7.0.0-43-generic x86_64; Python 3.12.3; clang 18.1.3; AFL++ 4.09c;
`aapt` Build Tools 34.0.0; `apksigner` 0.9; adb 1.0.41; emulator 36.5.11.0;
Androguard 4.1.4. Emulator fingerprint
`Android/sdk_phone_x86_64/generic_x86_64:10/QSR1.210820.001/7663313:userdebug/test-keys`,
serial `emulator-5562`, `-no-snapshot -wipe-data`, `wifi_on=0`,
`mobile_data=0`, external ping "Network is unreachable". Shut down afterward;
`adb devices -l` empty. Origin APK `1dfce426…5b7a`; signed baseline
`f14653a6…625c`; new mutator binary
`ba42388c6fb50d7ce6917dc863b79b2047c14547b631f852fd5bd5093bb56496`.

## Code changes

Full diff against pre-edit snapshots: [code-changes.patch](code-changes.patch)
(21 files); snapshots in `prework/` with hashes in
`prework-sha256.txt`.

| Area | Change |
| --- | --- |
| `scripts/android_binary_xml.py` (new) | Reference structural check of a binary XML manifest: chunk framing, string-pool bounds and termination, string references, element nesting. |
| `src/custom_mutators/v2/strategies.{c,h}`, `cm_ApkVulFuzz2.c` | Same check in C (`apkfuzz_axml_valid`). New mode `manifest-axml-onebit`: applied to the parent before mutation (failing descendants restart from the origin, `source_reason=descendant_manifest_invalid`) and to each accepted output. Other modes take the old code path. |
| `src/compile_afl_mutator_variants.sh`, `scripts/run-fdroid-locked-arm.sh`, `scripts/run-fdroid-local-sampled-arm.py`, `tests/check_variant_window.py`, v2 `README.md` | Register the new variant. Only this variant was built; the 19 existing `.so` hashes are unchanged (`mutators-before-sha256.txt` vs `mutators-after-sha256.txt`). |
| `scripts/inspect-runtime-candidates.py`, `prepare-manifest-runtime-candidate.py`, `analyze-live-mutation-sample.py`, `probe-android-runtime.py` | Any `aapt` resource-parser warning is invalid even on exit 0; a manifest failing the structure check is blocked. |
| `scripts/probe-android-runtime.py` | `launched_process_running` now needs a running process, no fatal exception for the package since the probe began (time-bounded crash buffer), and — for a prepared mutant — the baseline's resolved activity via a required `--baseline-probe-report`. New classes `launched_crashed`, `launched_unexpected_activity`, `crash_check_failed`, `device_clock_unavailable`. |
| `scripts/llmdroid-analysis-queue.py`, `run-fdroid-agent-stage.py` | A pair is `ready` only with a matching passing device report (`--device-report`); otherwise `device_launch_gate_missing` / `device_launch_gate_failed`. |
| Tests | New `tests/test_axml_structure.py` and `tests/axml_check_driver.c`; extended probe, queue, preflight, and mutator tests. |

## Verification before the experiment

- `bash scripts/run-tests.sh` exit 0, `ALL TESTS PASSED`, 20 variants in the
  sanity check (`run-tests.log`); `git diff --check` exit 0.
- C and Python structure checks agree on 4,532 single-byte changes to the real
  F-Droid manifest and on eleven hand-built damage classes.
- Existing modes are behaviorally unchanged by the source edit: rebuilds of
  `manifest-valid-onebit`, `manifest-onebit`, `manifest-bitflip`, and
  `random-range` from the edited source produced byte-identical driver output
  to the existing binaries for 12 rounds at seeds 5 and 77.
- Against step A's device results, the structure check rejects 12 of the 38
  generation-one "ready" mutants: 11 that failed to install and 1 that ran
  normally. It also rejects the damaged 10434 parent and all 30 of its
  "ready" children. The tightened preparation tool now refuses that parent.

## Experiment

```bash
APKFUZZ_ONLY_VARIANT=manifest-axml-onebit bash src/compile_afl_mutator_variants.sh
python3 -B scripts/run-fdroid-local-sampled-arm.py 120 10435 \
  results/axml-onebit-descendant-diagnostic-2026-11-15-10435 \
  --mode manifest-axml-onebit --gen1-first 0 --gen1-rate 1000 \
  --descendant-rate 50 --max-capture-bytes 2000000000          # exit 0
python3 -B scripts/prepare-manifest-runtime-candidate.py ... --output-dir \
  results/axml-admission-gate-2026-11-15/queue-prepared-0001  # exit 0
python3 -B scripts/probe-android-runtime.py --prepared-report .../preparation.json \
  --use-prepared-baseline --execute --serial emulator-5562 --timeout 30 --settle 2 \
  --output .../queue-baseline-probe.json                       # launched_process_running
python3 -B scripts/probe-android-runtime.py --prepared-report .../preparation.json \
  --baseline-probe-report .../queue-baseline-probe.json --execute --serial emulator-5562 \
  --timeout 30 --settle 2 --output .../queue-mutant-probe.json # launched_process_running
python3 -B results/axml-admission-gate-2026-11-15/cohort_probe.py \
  --serial emulator-5562 --timeout 30 --settle 2               # exit 0, 45/45 probes
python3 -B scripts/llmdroid-analysis-queue.py plan ... [--device-report .../queue-mutant-probe.json]
.venv-llmdroid/bin/python -B scripts/run-llmdroid-pair.py --checkout .deps/LLMDroid \
  --baseline-apk <baseline> --mutant-apk <baseline | iter-000000043-g2.apk> \
  --trace results/fdroid-signed-guided-2026-11-04/trace.json --serial emulator-5562 \
  --output-dir ... --timeout-per-run 240 --interval 2          # both exit 0
```

### AFL stage (Python-harness activity only)

Runner, watcher, and analyzer exit 0; source and input drift false. 4,568
harness executions at 38.05/s; final corpus 2 (one new); zero saved harness
crashes or hangs. Mutator log: 4,515 operations, all `status=ok`,
`source_reason=none`; 24 generation one, 4,491 generation two. The single new
queue entry is again iteration 1 at 33 executions with no coverage flag. No
entry was added for new coverage in this run, and no fallback was needed.

### Offline stage

95 of 95 selected live outputs captured (1,180,496,220 bytes, under the 2 GB
cap), all generation two, **all children of the one queue parent**
(exact `538cc4c2…bc14`, a three-byte string-data change). Lineage, raw ZIP,
structure, `aapt`, and signing passed for 95/95; 94 passed the matched-pair
check and were `ready_for_install_attempt` (one failed that pair check).

### Device stage

| Probe | Result |
| --- | --- |
| Baseline first / middle / last | `launched_process_running` ×3, `MainActivity`, 0 fatal exceptions |
| Gate control: known-healthy mutant (10432 iteration 1) | `launched_process_running` (required) |
| Gate control: known start-up crasher (10433 iteration 15) | `launched_crashed`, 7 fatal exceptions (required) |
| Queue parent via the real tools | baseline and mutant both `launched_process_running`; mutant resolved the baseline's activity |

| 40 generation-two mutants (first 40 of 94 offline-ready, iteration order) | Count |
| --- | ---: |
| `launched_process_running` under the new gate | **28** |
| `launched_crashed` (fatal exception at start; crash-report dialog) | 6 |
| `launch_failed` | 5 |
| `install_failed` (`INSTALL_PARSE_FAILED_MANIFEST_MALFORMED`) | 1 |

Of the five launch failures, four could not resolve the launcher intent and
one hit a 30-second adb timeout on the launcher command before its explicit
activity was reported missing. The six crashes were missing-permission or
missing-class errors (`SecurityException`, `Unable to instantiate activity`,
`Permission … is required`). By changed region: string data 16 healthy of 27;
XML node tree 12 healthy of 13. Cleanup was complete for all 45 probes.

### Admission and replay

`plan` without a device report: `ready 0, blocked 1`
(`device_launch_gate_missing`). With the mutant's report: `ready 1`.
Original/original control and the generation-two pair for iteration 43
(signed `248e4bfc…7e33`): both roles completed 8 of 8 steps, every step `ok`,
status `no_divergence_observed`.

## Interpretation

1. Keeping binary XML structure sound in the mutator, and keeping broken
   descendants out of the parent pool, is sufficient for live generation-two
   mutants to install and run in this run (28/40 vs. 0/30 previously).
2. The offline gate is now a better but still imperfect predictor: 12 of 40
   offline-ready mutants failed on the device, all for *semantic* reasons
   (a permission, component class, or launcher entry no longer named
   correctly). The device gate caught every one; six of them would have been
   called "running" by the old process-only check.
3. The old `launched_process_running` would have admitted start-up crashers to
   LLMDroid, where they would surface as trivial "divergences".

## What this does not show

- **Confounded comparison.** Seed 10435 and seed 10434 differ in mode *and* in
  which first mutant AFL queued. This run's parent happened to be healthy; the
  new mode guarantees a structurally sound parent, not a working one.
- **One parent, one generation.** All 95 samples descend from one parent and
  are generation two. Generation three and beyond are unmeasured.
- **AFL's feedback contributes nothing here.** With structurally valid
  mutants the Python harness saw no new coverage in 120 s, so the queue stayed
  at the seed plus the first mutant. A longer run in this mode would mostly
  resample children of that one parent; the manifest has only 71,368 possible
  first-generation one-bit flips. Coverage and crash counts still describe the
  harness, not F-Droid.
- **Not a yield rate.** 40 of 94 ready mutants were probed once each, in
  iteration order; no repetition and no confidence interval.
- **No defect.** Install failures and start-up crashes are expected effects of
  the mutation. The single replay pair showed no divergence.
- **Classification gap.** An adb-level timeout of the launcher command is
  still classed `launch_failed`; it should be an inconclusive timeout class.
  Not changed here because it would post-date this evidence.
- The structure check is stricter than Android in rare cases (it rejected one
  mutant that ran normally in step A).

## Evidence (SHA-256)

- `PROTOCOL.md` `5de9b1b421427611dedc76b8b709364117eb1f16c7574b4db7e1db2ebfa4c216`
- `cohort_probe.py` `879abc1f34397fd25894cee9f672fb3e27408b690fbab7b4f111ab2995dd7e47`
- `cohort-device-admission.json` `31f5e2255811a6f2111b323a2b6c4757cd3d0b19cd155917ddebd00725fd4b60`
- `queue-prepared-0001/preparation.json` `dc5bc9b0634b4e738aec727f0fba2663b930f3d779fa66ba28524a272261366c`
- `queue-baseline-probe.json` `3086789adce041573cbc584777af2a218ebcd8da1b730a15122f5fda8f51e19f`
- `queue-mutant-probe.json` `a4693a34ec7d240c16211d7fea83f04dce85dac17406556371d2b4c97db1db27`
- `analysis-plan.json` `927023ba7f984f695a7c01fbe504139b626cb77640c1452ac339017d834449b2`
- `analysis-plan-without-device-report.json` `e09cd74edac1453d4ec6995c03a489273106428de95ed928a8481eb76894ee1d`
- `original-original-control/pair-report.json` `dd667e4470772ee2343f89d6f610202e77c21b49210294c35363e092f46b1ddf`
- `gen2-pair-iter43/pair-report.json` `488118d082946c0bf785135429e8db5fe7d7ec3110f05518a1a65ea90bd6280e`
- live analysis `9f20d7f0f651b3fecb144ac03a29d685c84db59630451d4a98d4abad465a50b8`
- `afl-run.log` `537335b7…`, `run-tests.log` `a1b18484…`, `emulator.log` `9db598d0…`

Raw AFL output is in `results/axml-onebit-descendant-diagnostic-2026-11-15-10435`
and its `-live-sample` / `-live-analysis` siblings.

## Next decision

Before any long run, decide what the long run is for. Options, in order of
how well the evidence supports them:

1. **Enumerate instead of fuzz.** Screen all 71,368 first-generation flips
   offline (structure + `aapt`), device-gate the survivors in batches, and
   feed admitted pairs to paired replay. Deterministic, no parent lottery.
2. **Give AFL feedback that reflects Android.** Otherwise queue growth stays
   unrelated to app behavior.
3. **Bounded multi-generation check** (for example gen cap 3 with several
   seeds) to measure whether admission decays past generation two.

Also: classify adb-level launch timeouts as inconclusive, and obtain the raw
VM `random-range` artifacts.
