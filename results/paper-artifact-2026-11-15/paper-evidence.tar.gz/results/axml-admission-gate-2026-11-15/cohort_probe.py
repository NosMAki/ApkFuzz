#!/usr/bin/env python3
"""Device launch gate for the later-generation cohort; see PROTOCOL.md.

Uses device_probe() from scripts/probe-android-runtime.py unchanged, with the
baseline's resolved activity as the expected activity. Output is written once.
"""

import argparse
import hashlib
import importlib.util
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ANALYSIS = ROOT / "results/axml-onebit-descendant-diagnostic-2026-11-15-10435-live-analysis/analysis.json"
STEP_A = ROOT / "results/gen1-device-admission-2026-11-15/cohort.json"
CONTROLS = {"gen1_offline_ready:10432:iter1": "launched_process_running",
            "gen1_offline_ready:10433:iter15": "launched_crashed"}
COHORT_LIMIT = 40


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--serial", required=True)
    parser.add_argument("--adb", default="adb")
    parser.add_argument("--apksigner", default="/usr/bin/apksigner")
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--settle", type=float, default=2.0)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location(
        "apkfuzz_probe", ROOT / "scripts/probe-android-runtime.py")
    probe = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(probe)
    aapt = probe.preflight.find_aapt()
    analysis = json.loads(ANALYSIS.read_text())
    ready = sorted((c for c in analysis["candidates"] if c["generation"] >= 2 and
                    c["admission"] == "ready_for_install_attempt"),
                   key=lambda c: c["iteration"])
    cohort = [{"id": f"gen{c['generation']}:10435:iter{c['iteration']}", "kind": "cohort",
               "apk": c["prepared_apk"], "sha256": c["prepared_sha256"],
               "exact_sha256": c["exact_sha256"]} for c in ready[:COHORT_LIMIT]]
    step_a = {item["id"]: item for item in json.loads(STEP_A.read_text())["items"]}
    controls = [{"id": name, "kind": "gate_control", "expect": expect,
                 "apk": step_a[name]["prepared_apk"], "sha256": step_a[name]["prepared_sha256"]}
                for name, expect in CONTROLS.items()]
    baseline = {"kind": "baseline", "expect": "launched_process_running",
                "apk": analysis["baseline_apk"], "sha256": analysis["baseline_sha256"]}
    half = len(cohort) // 2
    order = ([dict(baseline, id="baseline:first")] + controls + cohort[:half] +
             [dict(baseline, id="baseline:middle")] + cohort[half:] +
             [dict(baseline, id="baseline:last")])
    output = HERE / "cohort-device-admission.json"
    if output.exists():
        raise SystemExit("cohort-device-admission.json already exists")
    report = {"schema_version": 1, "started_utc": now(), "serial": args.serial,
              "timeout": args.timeout, "settle": args.settle,
              "launch_gate_version": probe.LAUNCH_GATE_VERSION,
              "source_analysis": str(ANALYSIS), "source_analysis_sha256": digest(ANALYSIS),
              "offline_ready_later_generation": len(ready), "cohort_limit": COHORT_LIMIT,
              "planned": len(order), "expected_activity": None, "status": "running",
              "attempts": []}

    def save():
        report["updated_utc"] = now()
        output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    def stop(status):
        report["status"] = status
        report["finished_utc"] = now()
        save()
        print(status)
        return 3

    for item in order:
        apk = Path(item["apk"])
        if digest(apk) != item["sha256"]:
            raise SystemExit(f"hash changed: {apk}")
        row = {"id": item["id"], "kind": item["kind"], "tested_apk_sha256": item["sha256"],
               "exact_sha256": item.get("exact_sha256"), "started_utc": now()}
        row["signature"] = probe.run_command([args.apksigner, "verify", str(apk)],
                                             args.timeout)["status"]
        meta, package, activity = probe.package_metadata(aapt, apk, args.timeout)
        row.update(aapt_status=meta["status"], package=package)
        if row["signature"] != "ok" or meta["status"] != "ok" or not package:
            row["classification"] = "skipped_offline_gate"
        else:
            runtime = probe.device_probe(args.adb, args.serial, apk, package, activity,
                                         args.timeout, args.settle,
                                         report["expected_activity"])
            row["device_probe"] = runtime
            row["classification"] = runtime["classification"]
        report["attempts"].append(row)
        save()
        print(f"{len(report['attempts']):2d}/{len(order)} {item['id']}: {row['classification']}",
              flush=True)
        runtime = row.get("device_probe") or {}
        cleanup = runtime.get("cleanup")
        if row["classification"] in ("device_unavailable", "device_not_ready",
                                     "device_clock_unavailable", "crash_check_failed"):
            return stop("aborted_device_or_crash_check")
        if cleanup and not cleanup["complete"]:
            return stop("aborted_cleanup_incomplete")
        if item.get("expect") and row["classification"] != item["expect"]:
            return stop("aborted_baseline_failed" if item["kind"] == "baseline"
                        else "aborted_gate_control_failed")
        if item["id"] == "baseline:first":
            report["expected_activity"] = runtime["resolved_activity"]
            if not report["expected_activity"]:
                return stop("aborted_baseline_activity_unknown")
    report["status"] = "completed"
    report["finished_utc"] = now()
    save()
    return 0


if __name__ == "__main__":
    sys.exit(main())
