# Generation-one device admission check — protocol (written before any run)

Date: 2026-11-15. Authorized by the user in chat ("Run step A"). Target: the
repository's F-Droid corpus APK and derivatives already preserved under
`results/`, on the local offline Android 29 emulator only. No AFL run, no code
change in the repository, no model call, no network-facing test.

## Questions and falsifiable hypotheses

- **H1 (inherited parent defect).** The generation-one queue parent of the
  2026-11-12 diagnostic run (seed 10434, exact SHA-256 `35403ac8…7651`), once
  test-signed without other changes, fails Android installation or launch by
  itself, and LLMDroid's Androguard parser rejects it. *Falsified* if it
  installs and shows a running `org.fdroid.fdroid` process like the baseline.
- **H2 (offline gate overstates generation one).** Among the 38 preserved
  generation-one APKs that the offline gate marked `ready_for_install_attempt`
  (20 from run 10432, 18 from run 10433), fewer than 38 reach
  `launched_process_running`. *Falsified* if all 38 do.
- **H3 (failures follow the damaged manifest region).** Failures concentrate
  in mutants whose decoded manifest change touches the string-pool offset
  table. Descriptive only; the cohorts are small and deliberately selected.

## Fixed inputs

- Cohort: every generation-one row with `admission == ready_for_install_attempt`
  in the two `*-live-analysis/analysis.json` files (no sampling), plus the
  newly test-signed diagnostic parent. Frozen in `cohort.json` with exact and
  prepared SHA-256 values before the emulator starts.
- Control: matched test-signed baseline, SHA-256 `f14653a6…625c`, probed
  first, between the two cohorts, and last.
- Known positive: run 10432 iteration 1 (prepared `3dbe961a…6e2a`), which
  launched on 2026-11-12.
- Tools: existing `scripts/prepare-manifest-runtime-candidate.py` and the
  `device_probe`/`package_metadata` functions of
  `scripts/probe-android-runtime.py`, unchanged. `--timeout 30`, settle 2 s.
- Emulator: AVD `apkfuzz_fdroid29`, port 5562, `-no-snapshot -wipe-data`,
  Wi-Fi and mobile data disabled before the first install.

## Measured outcomes (separate denominators)

Offline `aapt` (exit code, any stderr warning), Androguard parse as LLMDroid
performs it, Android install, launch, and process-running classification,
cleanup. Exact AFL bytes, signed derivatives, and the baseline keep distinct
hashes. These cohorts are the targeted first-24 generation-one prefix of each
run, not a uniform sample; no yield rate is generalized from them.

## Stop conditions

Stop and report inconclusive infrastructure, preserving partial output, if:
the emulator does not finish booting in 300 s; any baseline probe is not
`launched_process_running`; a probe reports `device_unavailable` or
`device_not_ready`; or cleanup is incomplete for any APK. Resource limits:
at most 42 device probes, 30 s per adb command, one emulator, shut down with
`adb emu kill` at the end and verified with `adb devices -l`.

## Interpretation limits

A failed install or launch of a mutated manifest is an expected consequence of
corrupting it and is not an application defect or vulnerability. An emulator,
adb, or parser fault is infrastructure evidence only.
