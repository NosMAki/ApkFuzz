# Generation-one device admission check — 2026-11-15

## Conclusion

On a fresh offline Android 29 emulator, **22 of 38** preserved generation-one
mutants that the offline gate had marked `ready_for_install_attempt` launched
F-Droid's `MainActivity` with no crash logged. Thirteen failed installation
and three installed but crashed at application start. The generation-one queue
parent of the 2026-11-12 diagnostic (seed 10434) **failed installation by
itself**. The three baseline probes (first, middle, last) all launched
normally, and every APK was removed afterward.

This supports all three pre-registered hypotheses in [PROTOCOL.md](PROTOCOL.md):

- **H1 supported (one observation).** The signed parent was rejected by
  Android (`INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION: Failed to read
  manifest`) and by Androguard (`parse_error`). All 55 sampled generation-two
  outputs of that run descend from this parent, so the earlier 2/30 install
  result is dominated by one inherited defect rather than showing a general
  loss of validity at generation two.
- **H2 supported.** The offline gate overstates Android admission at
  generation one as well: 38 offline-ready → 25 installed → 22 healthy.
- **H3 partly supported.** All five mutants whose change fell in the
  string-pool offset table failed to install (six of six with the parent),
  but eight of the thirteen install failures were in other regions.

No result here is an application defect or vulnerability. Every failure is the
expected effect of corrupting the manifest.

## Authorization, scope, environment

Authorized by the user in chat on 2026-11-15 ("Run step A"). Local F-Droid
corpus APK and already-preserved derivatives only. No AFL run, no model call,
no VM, no repository source or documentation change; `git status --short`
still lists 81 entries. All new files are in this ignored directory.

Git HEAD `96f82a05f0376d4f79b897b72f6a6d17d907143d` with the pre-existing
uncommitted work. Linux 7.0.0-43-generic x86_64; Python 3.12.3; `aapt`
Build Tools 34.0.0; `apksigner` 0.9; adb 1.0.41 (37.0.0); emulator 36.5.11.0;
Androguard 4.1.4 in `.venv-llmdroid`. Emulator fingerprint
`Android/sdk_phone_x86_64/generic_x86_64:10/QSR1.210820.001/7663313:userdebug/test-keys`,
serial `emulator-5562`, AVD `apkfuzz_fdroid29` started with
`-no-snapshot -wipe-data`; `wifi_on=0`, `mobile_data=0`, and a ping to an
external address returned "Network is unreachable" before the first install.
Origin APK SHA-256 `1dfce426…5b7a`; signed baseline `f14653a6…625c`.

## Commands

```bash
python3 -B scripts/prepare-manifest-runtime-candidate.py \
  --capture-manifest results/manifest-valid-onebit-descendant-diagnostic-2026-11-12-10434/afl/candidates/manifest.json \
  --preflight-report results/manifest-valid-onebit-descendant-diagnostic-2026-11-12-10434/candidate-preflight.json \
  --queue-entry 'id:000001,src:000000,time:156,execs:33,op:cm-ApkVulFuzz2-manife,pos:0' \
  --key results/llmdroid-positive-control-2026-10-21/signing/key.pk8 \
  --cert results/llmdroid-positive-control-2026-10-21/signing/cert.pem \
  --output-dir results/gen1-device-admission-2026-11-15/parent-prepared        # exit 0
python3 -B results/gen1-device-admission-2026-11-15/admission.py freeze         # exit 0, 39 items
.venv-llmdroid/bin/python -B results/gen1-device-admission-2026-11-15/admission.py parser   # exit 0
ANDROID_AVD_HOME="$PWD/results/llmdroid-fdroid-avd-home" emulator -avd apkfuzz_fdroid29 \
  -port 5562 -no-window -no-audio -no-boot-anim -gpu swiftshader_indirect -no-snapshot -wipe-data
adb -s emulator-5562 shell svc wifi disable; adb -s emulator-5562 shell svc data disable
python3 -B results/gen1-device-admission-2026-11-15/admission.py device \
  --serial emulator-5562 --timeout 30 --settle 2                                # exit 0, 42/42 probes
adb -s emulator-5562 emu kill                                                   # adb devices -l then empty
```

`admission.py` reuses `device_probe` and `package_metadata` from the unchanged
`scripts/probe-android-runtime.py`. Device probing ran 08:53:30–08:56:01 UTC.

## Cohort

Every generation-one `ready_for_install_attempt` row from the two saved
analyses — 20 from the 30-second run (seed 10432) and 18 from the ten-minute
run (seed 10433) — plus the newly signed diagnostic parent (exact
`35403ac8…7651`, signed `01e6701c…2420`). No sampling within those sets.
These are the deliberately targeted first-24 prefix of each run, **not** a
uniform sample of generation one. Exact, signed, and baseline hashes are
frozen in `cohort.json`. The known positive (run 10432 iteration 1, signed
`3dbe961a…6e2a`) launched again, matching 2026-11-12.

## Observed results

| Stage (38 generation-one offline-ready mutants) | Count |
| --- | ---: |
| `aapt dump badging` exit 0 with matching package line (the existing gate) | 38 |
| …of which `aapt` printed a `ResourceType W` warning on stderr | 8 |
| Androguard parse as LLMDroid performs it: accepted | 27 |
| Androguard: parse error 7, package not read 3, main activity differs 1 | 11 |
| Android install succeeded | 25 |
| Install failed (`…UNEXPECTED_EXCEPTION` 11, `…MANIFEST_MALFORMED` 2) | 13 |
| Probe class `launched_process_running` | 24 |
| Launched `MainActivity`, no crash-buffer entry ("healthy") | 22 |
| Installed, then fatal exception in `FDroidApp.onCreate` | 3 |

| Offline signals vs. device outcome | Healthy | Crash at start | Install failed |
| --- | ---: | ---: | ---: |
| `aapt` clean, Androguard accepted | 21 | 3 | 1 |
| `aapt` clean, Androguard rejected | 1 | 0 | 4 |
| `aapt` warning, Androguard accepted | 0 | 0 | 2 |
| `aapt` warning, Androguard rejected | 0 | 0 | 6 |

| Decoded manifest region changed | Healthy | Crash at start | Install failed |
| --- | ---: | ---: | ---: |
| String-pool offset table | 0 | 0 | 5 |
| String-pool string data | 12 | 3 | 4 |
| XML node tree | 10 | 0 | 4 |

Parent (string-pool offset table, `aapt` warning "Bad string block: string
#247 entry is at 2301952, past end at 17516"): Androguard `parse_error`,
Android install failed. The existing preparation tool nevertheless reported it
`ready_for_install_attempt`.

The three start-up crashes are run 10433 iterations 15, 17, and 21. Their
string-data change removed a declared permission name: iteration 15 raised
`SecurityException … android.permission.ACCESS_NETWORK_STATE`; iterations 17
and 21 raised `Permission org.fdroid.fdroid.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION
is required`. The launcher resolved to `org.acra.dialog.CrashReportDialog`.
Two of the three were still classified `launched_process_running` because
`pidof` found the crash-report process.

## Interpretation

1. `aapt` exit 0 plus a matching package line is not an Android admission
   test at any generation. In this cohort any `aapt` stderr warning predicted
   install failure (8/8), so rejecting warnings would have removed eight
   failures without discarding a working mutant; five other install failures
   had no warning.
2. Androguard and Android disagree in both directions (one mutant Androguard
   rejected ran normally; six it accepted did not — three failed to install
   and three crashed at start), so the parser cannot stand in for a device
   install.
3. `launched_process_running` overstates health: a crash-report process
   satisfies it. A launch gate should also require the baseline's resolved
   activity and an empty crash buffer.
4. The diagnostic's generation-two cohort measured the children of one
   uninstallable parent. Whether generation two from an *installable* parent
   keeps a useful admission rate is still unmeasured.

## Limitations and confounders

- One probe per APK; no repetition, so flakiness is not estimated. The three
  baseline probes were consistent.
- Targeted first-24 prefixes from two runs; no population yield rate follows.
- `logcat -b crash -c` did not isolate probes: crash entries from iteration 15
  also appeared in the next row's capture. Crashes were therefore attributed
  by timestamp against each probe's start time, not by row.
- The process check is a single `pidof` two seconds after launch.
- Region labels are top-level binary-XML ranges of the original manifest; a
  change inside "string data" is not further classified by which string.
- The start-up crashes are single observations and expected consequences of
  deleting a permission declaration; they are not defect candidates in F-Droid.

## Evidence (SHA-256)

- `PROTOCOL.md` `18fbd37e27c24b918a9b829f67000eaeb1106ee93b3cc5aaacaebc2b1c8ac05c`
- `admission.py` `4e25ef5416075e4ed83ee334f12c08e772466db6325064509bb1e189e8e8b108`
- `cohort.json` `728d10423aa543aa8aa1f8e563772629da739684c7a677e56c77d4b7d97d61da`
- `parser-admission.json` `8b9d35a7910984602391c29b86274af2aa676a222cc0aff0895fdb47b2a6fab4`
- `device-admission.json` `e576d638ed360ad98845eceb248b9c16ffff29b66d649a45a7346fd84952e803`
- `device-run.log` `7a1a6f7c2ecdb5d4a08e067624beec856c3f76260bb6b67aa67c6460d0bcf750`
- `emulator.log` `d635c7c2f0ca3401a35f83eb1ea23c72f74966e96acf49fcd83f2b87624772ac`
- `parent-prepared/preparation.json` `417b7601606d57c51dfaa033ff5d6b753d6e19e62fc4b152d94a6a4f0f839651`

## Next experiment (not started)

Tighten admission, then measure generation two from a parent that is known to
install: reject any `aapt` resource warning offline; require a device result
of baseline activity, running process, and empty crash buffer before LLMDroid
admission; and keep broken descendants out of the parent pool so they fall
back to the origin. Then repeat the 120-second diagnostic sampling with a new
seed and an original/original control. `docs/LLMDROID_STAGE_STATUS.md` and
`docs/assistant-guidance/TASKS.md` have **not** been updated with this result.
