#!/usr/bin/env python3
"""Bounded generation-one admission check; see PROTOCOL.md in this directory.

Subcommands: freeze (offline cohort + hashes), parser (Androguard, run with the
LLMDroid interpreter), device (install/launch on one named emulator).
Outputs are created once and never overwritten.
"""

import argparse
import hashlib
import importlib.util
import json
import struct
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RESULTS = ROOT / "results"
ORIGIN = ROOT / "Evaluation-SSBSE-2026/apk/F-Droid.apk"
RUNS = ("manifest-valid-onebit-local-30s-2026-11-12-10432",
        "manifest-valid-onebit-local-10min-2026-11-12-10433")
BASELINE = RESULTS / f"{RUNS[0]}-live-analysis/prepared-baseline.apk"
PARENT_REPORT = HERE / "parent-prepared/preparation.json"
EXPECTED_PACKAGE = "org.fdroid.fdroid"


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def manifest(path):
    with zipfile.ZipFile(path) as archive:
        return archive.read("AndroidManifest.xml")


def regions(data):
    """Top-level byte ranges of an Android binary XML document."""
    pool = 8
    _, header, size = struct.unpack_from("<HHI", data, pool)
    count, _, _, strings_start, _ = struct.unpack_from("<IIIII", data, pool + 8)
    out = [("xml_header", 0, 8), ("strpool_header", pool, pool + header),
           ("strpool_offsets", pool + header, pool + header + 4 * count),
           ("strpool_data", pool + strings_start, pool + size)]
    cursor = pool + size
    kind, _, chunk = struct.unpack_from("<HHI", data, cursor)
    if kind == 0x0180:
        out.append(("resource_map", cursor, cursor + chunk))
        cursor += chunk
    out.append(("xml_nodes", cursor, len(data)))
    return out


def describe_change(original, mutated, layout):
    if len(original) != len(mutated):
        return {"changed_bytes": None, "regions": ["length_changed"]}
    changed = [i for i in range(len(original)) if original[i] != mutated[i]]
    named = sorted({next((n for n, a, e in layout if a <= i < e), "gap") for i in changed})
    return {"changed_bytes": len(changed), "first_offset": changed[0] if changed else None,
            "last_offset": changed[-1] if changed else None, "regions": named}


def load_probe():
    spec = importlib.util.spec_from_file_location(
        "apkfuzz_probe", ROOT / "scripts/probe-android-runtime.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_new(path, payload):
    with open(path, "x", encoding="utf-8") as target:
        json.dump(payload, target, indent=2)
        target.write("\n")


def freeze(args):
    probe = load_probe()
    aapt = probe.preflight.find_aapt()
    original = manifest(ORIGIN)
    layout = regions(original)
    items = []

    def add(kind, run, iteration, generation, exact, exact_sha, prepared, prepared_sha):
        exact, prepared = Path(exact), Path(prepared)
        if digest(exact) != exact_sha or digest(prepared) != prepared_sha:
            raise SystemExit(f"hash mismatch for {prepared}")
        mutated = manifest(exact)
        if manifest(prepared) != mutated:
            raise SystemExit(f"prepared manifest differs from exact for {prepared}")
        badging = probe.run_command([aapt, "dump", "badging", str(prepared)], 30, 200000)
        lines = badging.get("stdout", "").splitlines()
        items.append({
            "id": f"{kind}:{run.rsplit('-', 1)[-1]}:iter{iteration}",
            "kind": kind, "run": run, "iteration": iteration, "generation": generation,
            "exact_apk": str(exact), "exact_sha256": exact_sha,
            "prepared_apk": str(prepared), "prepared_sha256": prepared_sha,
            "manifest_sha256": hashlib.sha256(mutated).hexdigest(),
            "change": describe_change(original, mutated, layout),
            "aapt_exit_code": badging.get("exit_code"),
            "aapt_warning": badging.get("stderr", "")[:300],
            "aapt_package_line": lines[0][:200] if lines else None,
            "aapt_launchable": [l for l in lines if l.startswith("launchable-activity")][:3],
        })

    for run in RUNS:
        analysis = json.loads((RESULTS / f"{run}-live-analysis/analysis.json").read_text())
        rows = [c for c in analysis["candidates"]
                if c["generation"] == 1 and c["admission"] == "ready_for_install_attempt"]
        for row in sorted(rows, key=lambda c: c["iteration"]):
            add("gen1_offline_ready", run, row["iteration"], 1, row["exact_apk"],
                row["exact_sha256"], row["prepared_apk"], row["prepared_sha256"])
    parent = json.loads(PARENT_REPORT.read_text())
    if parent["prepared_baseline_sha256"] != digest(BASELINE):
        raise SystemExit("parent baseline differs from the cohort baseline")
    add("diag_gen1_queue_parent", "manifest-valid-onebit-descendant-diagnostic-2026-11-12-10434",
        int(parent["patch_iteration"]), 1, parent["exact_mutant_path"],
        parent["exact_mutant_sha256"], parent["prepared_apk_path"],
        parent["prepared_apk_sha256"])
    base_badging = probe.run_command([aapt, "dump", "badging", str(BASELINE)], 30, 200000)
    base_lines = base_badging["stdout"].splitlines()
    write_new(HERE / "cohort.json", {
        "schema_version": 1, "generated_utc": now(), "origin_sha256": digest(ORIGIN),
        "origin_manifest_regions": [{"name": n, "start": a, "end": e} for n, a, e in layout],
        "baseline_apk": str(BASELINE), "baseline_sha256": digest(BASELINE),
        "baseline_aapt_package_line": base_lines[0][:200],
        "baseline_aapt_launchable": [l for l in base_lines if l.startswith("launchable-activity")][:3],
        "baseline_aapt_warning": base_badging.get("stderr", "")[:300],
        "aapt": aapt, "driver_sha256": digest(__file__), "items": items})
    print(f"frozen {len(items)} cohort items")


def parser_check(args):
    import logging
    try:
        from loguru import logger as loguru_logger
        loguru_logger.remove()
    except ImportError:
        pass
    logging.disable(logging.CRITICAL)
    import androguard
    from androguard.core.apk import APK
    cohort = json.loads((HERE / "cohort.json").read_text())

    def parse(path):
        # Mirrors the calls LLMDroid-Droidbot/droidbot/app.py makes on load.
        try:
            apk = APK(str(path))
            info = {"package": apk.get_package(), "main_activity": apk.get_main_activity(),
                    "activities": len(apk.get_activities()),
                    "permissions": len(apk.get_permissions())}
        except Exception as exc:  # parser faults of any type are the measured outcome
            return {"status": "parse_error", "error_type": type(exc).__name__,
                    "detail": str(exc)[:200]}
        return info

    baseline = parse(cohort["baseline_apk"])
    if baseline.get("status") == "parse_error" or baseline["package"] != EXPECTED_PACKAGE:
        raise SystemExit(f"baseline did not parse as expected: {baseline}")
    results, counts = [], {}
    for item in cohort["items"]:
        if digest(item["prepared_apk"]) != item["prepared_sha256"]:
            raise SystemExit("cohort hash changed")
        row = parse(item["prepared_apk"])
        if "status" not in row:
            row["status"] = ("unexpected_package" if row["package"] != EXPECTED_PACKAGE else
                             "main_activity_differs" if row["main_activity"] != baseline["main_activity"] else
                             "metadata_count_differs" if (row["activities"], row["permissions"]) !=
                             (baseline["activities"], baseline["permissions"]) else "accepted")
        counts[row["status"]] = counts.get(row["status"], 0) + 1
        results.append({"id": item["id"], "prepared_sha256": item["prepared_sha256"], **row})
    write_new(HERE / "parser-admission.json", {
        "schema_version": 1, "generated_utc": now(), "androguard_version": androguard.__version__,
        "python": sys.version.split()[0], "expected_package": EXPECTED_PACKAGE,
        "baseline": baseline, "counts": counts, "results": results})
    print(json.dumps(counts, sort_keys=True))


def device_check(args):
    probe = load_probe()
    aapt = probe.preflight.find_aapt()
    cohort = json.loads((HERE / "cohort.json").read_text())
    by_kind = lambda kind, run=None: [i for i in cohort["items"] if i["kind"] == kind
                                      and (run is None or i["run"] == run)]
    baseline = {"id": "baseline", "kind": "baseline", "prepared_apk": cohort["baseline_apk"],
                "prepared_sha256": cohort["baseline_sha256"]}
    order = ([dict(baseline, id="baseline:first")] + by_kind("diag_gen1_queue_parent") +
             by_kind("gen1_offline_ready", RUNS[0]) + [dict(baseline, id="baseline:middle")] +
             by_kind("gen1_offline_ready", RUNS[1]) + [dict(baseline, id="baseline:last")])
    if len(order) > 42:
        raise SystemExit("probe count exceeds the protocol limit")
    adb = lambda *parts: probe.run_command([args.adb, "-s", args.serial, *parts], args.timeout, 4000)
    report = {"schema_version": 1, "started_utc": now(), "serial": args.serial,
              "timeout": args.timeout, "settle": args.settle, "planned": len(order),
              "fingerprint": adb("shell", "getprop", "ro.build.fingerprint").get("stdout"),
              "wifi": adb("shell", "settings", "get", "global", "wifi_on").get("stdout"),
              "mobile_data": adb("shell", "settings", "get", "global", "mobile_data").get("stdout"),
              "status": "running", "attempts": []}
    output = HERE / "device-admission.json"
    if output.exists():
        raise SystemExit("device-admission.json already exists")

    def save():
        report["updated_utc"] = now()
        output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    for item in order:
        apk = Path(item["prepared_apk"])
        row = {"id": item["id"], "kind": item["kind"], "prepared_sha256": item["prepared_sha256"],
               "started_utc": now()}
        if digest(apk) != item["prepared_sha256"]:
            raise SystemExit("cohort hash changed")
        row["signature"] = probe.run_command([args.apksigner, "verify", str(apk)], args.timeout)["status"]
        meta, package, activity = probe.package_metadata(aapt, apk, args.timeout)
        row.update(aapt_status=meta["status"], package=package, launch_activity=activity)
        if row["signature"] != "ok" or meta["status"] != "ok" or not package:
            row["classification"] = "skipped_offline_gate"
        else:
            adb("logcat", "-b", "crash", "-c")
            runtime = probe.device_probe(args.adb, args.serial, apk, package, activity,
                                         args.timeout, args.settle)
            row["device_probe"] = runtime
            row["classification"] = runtime["classification"]
            row["crash_log"] = adb("logcat", "-b", "crash", "-d").get("stdout", "")[-3000:]
            row["expected_package_after"] = adb("shell", "pm", "path", EXPECTED_PACKAGE)
        report["attempts"].append(row)
        save()
        print(f"{len(report['attempts']):2d}/{len(order)} {item['id']}: {row['classification']}", flush=True)
        cleanup = (row.get("device_probe") or {}).get("cleanup")
        stop = None
        if row["classification"] in ("device_unavailable", "device_not_ready"):
            stop = "aborted_device_unavailable"
        elif item["kind"] == "baseline" and row["classification"] != "launched_process_running":
            stop = "aborted_baseline_failed"
        elif (cleanup and not cleanup["complete"]) or (
                "expected_package_after" in row and
                not probe.package_absent(row["expected_package_after"])):
            stop = "aborted_cleanup_incomplete"
        if stop:
            report["status"] = stop
            report["finished_utc"] = now()
            save()
            print(stop)
            return 3
    report["status"] = "completed"
    report["finished_utc"] = now()
    save()
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("freeze")
    sub.add_parser("parser")
    device = sub.add_parser("device")
    device.add_argument("--serial", required=True)
    device.add_argument("--adb", default="adb")
    device.add_argument("--apksigner", default="/usr/bin/apksigner")
    device.add_argument("--timeout", type=int, default=30)
    device.add_argument("--settle", type=float, default=2.0)
    args = parser.parse_args()
    return {"freeze": freeze, "parser": parser_check, "device": device_check}[args.command](args) or 0


if __name__ == "__main__":
    sys.exit(main())
