# Exhaustive first-generation enumeration — protocol

Written 2026-11-15 before the enumeration. Authorized by the user in chat
("Enumerate gen-1 flips"). Local F-Droid corpus APK and the local offline
Android 29 emulator only. No AFL run, no model call, no VM, no network-facing
test. Historical evidence and mutator binaries are not modified.

## Question

Across **every** one-bit change to F-Droid's compressed manifest, how many
produce an APK that the `manifest-axml-onebit` mode would accept, and what
share of those launch healthily on Android? This replaces "whatever AFL
queued first" with a complete, deterministic generation-one population.

## Stage 1: offline enumeration (complete, no sampling)

For each of the 8 × compressed-size bit positions, apply the flip and classify
with the same acceptance rule as the mutator: the raw-deflate stream must end
exactly at the compressed size, decode to the original length with different
content, and pass `scripts/android_binary_xml.py`. Record one class per flip.
Deterministic; no random numbers.

Cross-checks against independent C-mutator output already on disk:

- every saved generation-one patch from the `manifest-axml-onebit` run (seed
  10435) must fall in the enumerated *accepted* set with the same CRC edits;
- every saved generation-one patch from the `manifest-valid-onebit` runs
  (seeds 10432, 10434) must be enumerated as deflate-valid;
- among the 848 generation-one flips of the legacy one-bit run (seed 10420),
  the number enumerated as deflate-valid should match the 388 that its
  separate screen found repairable and ZIP-valid.

Any disagreement stops the experiment before the device stage.

## Stage 2: device batch (uniform sample)

- Frame: all accepted flips. Draw 120 without replacement using
  `random.Random(10436)` over the frame sorted by (offset, bit).
- Build each APK as the mutator would (one bit, both manifest CRC fields),
  write a v2 patch, and run the unchanged
  `scripts/analyze-live-mutation-sample.py` for lineage, ZIP, structure,
  `aapt`, signing, and matched-pair checks. These APKs are **enumerated
  reconstructions, not AFL captures**, and are reported under their own
  denominator.
- Probe every offline-ready sample member once with the launch gate
  (`launched_process_running` = running process, no fatal exception for the
  package, baseline activity). Baseline probed first, after every 30 mutants,
  and last. Gate controls first: run 10432 iteration 1 must be
  `launched_process_running`; run 10433 iteration 15 must be `launched_crashed`.
- Emulator: AVD `apkfuzz_fdroid29`, port 5562, `-no-snapshot -wipe-data`,
  Wi-Fi and mobile data disabled.

## Outcomes

Counts per enumeration class; for the sample, offline-ready and device classes
with a Wilson 95% interval for the healthy share of accepted flips; a
projection of healthy generation-one mutants in the whole space and of the
device time a full pass would need. Sample members blocked offline count as
not admitted. No full device pass is run in this step.

## Stop conditions and limits

Stop and report if: a cross-check disagrees; the analyzer exits nonzero; the
emulator does not boot in 300 s; a baseline probe is not
`launched_process_running`; a gate control gives the wrong class; the device
becomes unavailable or a crash check fails; or cleanup is incomplete. Limits:
one enumeration pass, 120 sampled APKs (about 3 GB including signed copies),
at most 130 device probes, 30 s per adb command, one emulator shut down and
verified at the end.

## Interpretation limits

One app, one Android version, one probe per APK. A healthy launch is not a
behavioral test: paired UI replay of admitted mutants is a later step. Install
failures and start-up crashes are expected effects of the mutation, not
F-Droid defects.

## Amendment, 2026-11-15, written before the rerun

The first device attempt stopped at probe 42 of 122 with a harness error, not a
device or APK outcome: a crash log contained a non-UTF-8 byte and the probe's
command wrapper decoded strictly. Its 41 completed probes, log, and emulator
log are preserved unmodified in `attempt1-aborted/`; F-Droid was absent from
the device afterward.

Changes made before the rerun, with tests, full suite passing:
`scripts/probe-android-runtime.py` (and the two offline tool wrappers) decode
tool output with replacement, and a fatal exception logged for the package now
classifies as `launched_crashed` even when the launch command itself timed out
(three attempt-1 probes had exactly that combination).

Deviation from the original limits: the whole 115-member batch is rerun on one
code version, so total device probes are 41 + 122 = 163 instead of at most
130. The rerun, not attempt 1, supplies the reported counts. The 37 sample
members with a recorded attempt-1 result are compared as a repeat-consistency check; attempt-1
classes are re-derived under the new crash rule for that comparison only.
Everything else in the protocol is unchanged.
