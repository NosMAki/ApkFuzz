# Exhaustive first-generation enumeration — 2026-11-15

## Conclusion

All 71,368 one-bit changes to F-Droid's compressed manifest were classified
offline. **16,024 (22.5%)** are ones the `manifest-axml-onebit` mode would
accept. In a uniform random sample of 120 of those, **93 launched F-Droid's
`MainActivity` with no crash** on a fresh offline Android 29 emulator:
77.5%, Wilson 95% interval 69.2–84.1%. That projects to roughly 12,400
(11,100–13,500) healthy first-generation mutants in the whole space, about
17% of all flips.

The population is therefore known and reproducible without AFL: no parent
lottery, no dependence on which mutant the Python harness happens to queue.
The bottleneck has moved from producing Android-usable mutants to deciding
which of thousands are worth a behavioral test.

No result here is an F-Droid defect or vulnerability.

## Authorization, scope, environment

Authorized by the user in chat on 2026-11-15 ("Enumerate gen-1 flips"). Local
F-Droid corpus APK and local offline emulator only; no AFL run, model call,
VM, or network-facing test. Git HEAD `96f82a05f0376d4f79b897b72f6a6d17d907143d`
plus uncommitted work; nothing committed. Same host and tool versions as the
[gate and variant check](../axml-admission-gate-2026-11-15/REVIEW.md).
Emulator fingerprint
`Android/sdk_phone_x86_64/generic_x86_64:10/QSR1.210820.001/7663313:userdebug/test-keys`,
`emulator-5562`, `-no-snapshot -wipe-data`, Wi-Fi and mobile data off, external
ping unreachable; shut down afterward and `adb devices -l` empty. Origin APK
`1dfce426…5b7a`; signed baseline `f14653a6…625c`. Protocol, including one
amendment written before the rerun: [PROTOCOL.md](PROTOCOL.md).

## Commands

```bash
python3 -B results/gen1-enumeration-2026-11-15/enumerate.py enumerate    # exit 0, 70 s
python3 -B results/gen1-enumeration-2026-11-15/enumerate.py crosscheck   # exit 0, no failures
python3 -B results/gen1-enumeration-2026-11-15/enumerate.py sample       # 120 of 16,024, seed 10436
python3 -B scripts/analyze-live-mutation-sample.py \
  --sample-dir results/gen1-enumeration-2026-11-15-sample \
  --output-dir results/gen1-enumeration-2026-11-15-analysis              # exit 0
python3 -B results/gen1-enumeration-2026-11-15/sample_probe.py \
  --serial emulator-5562 --timeout 30 --settle 2                         # rerun: exit 0, 122/122
```

## Stage 1: enumeration (complete)

| Class of one-bit flip | Count | Share |
| --- | ---: | ---: |
| Deflate stream no longer decodes to the original length | 39,508 | 55.4% |
| Decodes, content unchanged | 20 | 0.0% |
| Decodes and changes content, binary XML structure broken | 15,816 | 22.2% |
| **Accepted** (decodes, changes content, structure sound) | **16,024** | **22.5%** |
| Total | 71,368 | |

The 16,024 accepted flips give 15,888 distinct decoded manifests. By region of
the decoded change: string data 9,493; XML node tree 6,120; resource map 326;
string data and nodes 42; string-offset table 41; string-pool header 2. By
size: one decoded byte 6,088; 2–8 bytes 5,431; 9–64 bytes 3,439; more 1,066.
The largest structure-rejection classes are unterminated strings (5,334),
out-of-range string references (4,545), and bad attribute values (3,716).

**Cross-checks against saved C-mutator output, all exact:**

- 24 of 24 generation-one patches from the `manifest-axml-onebit` run (seed
  10435) are in the accepted set, with byte-identical CRC edits;
- 48 of 48 generation-one patches from the two `manifest-valid-onebit` runs
  (seeds 10432, 10434) are enumerated as deflate-valid;
- of the 848 generation-one flips in the legacy one-bit run (seed 10420), 388
  are enumerated as deflate-valid — the same number its separate
  CRC-repair screen reported on 2026-11-12.

## Stage 2: uniform sample of 120 accepted flips

These APKs are **offline reconstructions of what the mutator would emit, not
AFL captures**, and form their own denominator.

| Stage | Count |
| --- | ---: |
| Sampled accepted flips (`random.Random(10436)`, sorted frame) | 120 |
| Lineage, raw ZIP, structure, `aapt`, signing valid | 120 |
| Matched-pair check valid → `ready_for_install_attempt` | 115 |
| Device gate `launched_process_running` | **93** |
| `launched_crashed` (fatal exception at start) | 12 |
| `install_failed` (`INSTALL_PARSE_FAILED_MANIFEST_MALFORMED`) | 6 |
| `launch_failed` (launcher intent no longer resolves) | 4 |

Healthy share: 93/120 = 77.5% of accepted flips (Wilson 95%: 69.2–84.1%);
93/115 = 80.9% of offline-ready (72.7–87.0%). By region in the sample: XML
node tree 54 healthy of 57; string data 39 of 58. By decoded change size:
one byte 52 of 54; 2–8 bytes 24 of 31; nine or more 17 of 30. No sampled flip
fell in the resource map or offset table (2.3% of the frame).

Controls: baseline `launched_process_running` at all five positions; the
known-healthy mutant passed and the known start-up crasher was
`launched_crashed`, as required. Cleanup complete for all 122 probes; F-Droid
absent afterward. 5.65 s per probe.

**Repeat consistency.** The 37 sample members that also have a recorded result
from the aborted first attempt (a separate wiped emulator session) received
the same class both times, 37 of 37, once attempt-1 classes are re-derived
under the crash rule below.

## Harness failure and fixes during this step

The first device attempt stopped at probe 42 of 122 with a Python
`UnicodeDecodeError`: a crash log contained a non-UTF-8 byte from a mutated
component name, and the probe's command wrapper decoded strictly. This was a
harness fault, not a device or APK outcome. Its files are preserved in
`attempt1-aborted/`. Changes ([code-changes.patch](code-changes.patch), four
files, snapshots in `prework/`):

- tool output is decoded with replacement in `probe-android-runtime.py`,
  `prepare-manifest-runtime-candidate.py`, and `inspect-runtime-candidates.py`;
- an adb-level timeout of the launcher command is no longer `launch_failed`:
  with a fatal exception logged for the package it is `launched_crashed`,
  otherwise an inconclusive `launch_timeout_*` class. Four rerun probes had a
  timed-out launcher command together with a logged fatal exception;
- three new probe tests; `bash scripts/run-tests.sh` exit 0, `ALL TESTS PASSED`,
  20 variants (`run-tests.log`); `git diff --check` exit 0.

Deviation from the protocol's limit: 41 + 122 = 163 device probes instead of
at most 130, recorded in the amendment before the rerun. Reported counts come
from the rerun only. The offline analysis ran before the decoding change; it
did not encounter undecodable output.

## Interpretation

1. First-generation one-bit manifest mutation of this APK is a finite,
   fully enumerable space, and about three quarters of the structurally sound
   part launches normally. Earlier impressions of low yield came from gates
   that admitted structurally broken manifests and from single arbitrary
   queue parents.
2. Small decoded changes are the reliable ones: one-byte changes were healthy
   in 52 of 54 sampled cases. The node tree is more forgiving than string
   data, where a changed permission or class name breaks start-up.
3. AFL's queue is not needed to obtain these candidates, and its Python-harness
   feedback does not rank them. Any long AFL run in this mode would resample
   a population that is now listed in `enumeration.tsv`.

## Limits

- One app, one Android version, one emulator image.
- The device figure is a sample estimate; 15,904 accepted flips are unprobed.
  A full device pass would take about 25 hours at the measured rate.
- "Healthy" means launched without a logged crash within about two seconds.
  It says nothing yet about behavior during use; no paired replay was run in
  this step.
- Generation one only. Combining two or more accepted flips is unmeasured
  beyond the 40-mutant generation-two cohort from one parent.
- The structure check is slightly stricter than Android, so a few working
  mutants are excluded from the accepted set.
- The sample APKs were built by `enumerate.py`, so their "lineage verified"
  status confirms internal consistency; independence comes from the three
  cross-checks above.

## Evidence (SHA-256)

- `PROTOCOL.md` `0a55ee8a9d7777664f384800566cc88c301fdaa94b7e79d57261db7f2093c32b`
- `enumerate.py` `6eaf07788d738d33163073a946ae1d27bbbaecad7588be27a10b0addc152301f`
- `enumeration.tsv` `65cd45238a1fce2b1f1463a4972e4fcf420743b97772194a6e1efd9cc1c70434`
- `enumeration-summary.json` `fc5c2bcfb98c891f5bf29993542b62800759c4243ec3c3eff7c0307bf502c9a6`
- `crosscheck.json` `0f93548ce20b8ce37fb8bc99b3175652c5133fab1a197af7531fe7713d1b29f0`
- `sample_probe.py` `077d0c638e5d37b442bd586365d5eee52b23f01e260c8c14ff9f55a0821bc0c1`
- `sample-device-admission.json` `980cca63e3aca9503e963f73937c178838ac80f5ba6ac837d449caf909d1a34e`
- sample `captures.jsonl` `8f7028c9103e9b7a2daf89241a8a5fec72c9c8db0f44fd6657a974a86de3bd9b`
- offline `analysis.json` `c03f65d227cdfd9c531fcaa8e75b3c667969c63fd09c635ab29b3adf62443131`
- `attempt1-aborted/sample-device-admission.json` `c07412e29df4e8c92feadc713a7ea9f146ef8090ed72b3f142d670411bb222f3`

Sample APKs and signed copies (about 1.4 GB each) are in the sibling
`-sample` and `-analysis` directories.

## Next decision

The open question is now selection, not generation. In order of cost:

1. **Classify every accepted flip by what it changes in the manifest**
   (which element and attribute: a permission, a component name, an
   `exported` or other flag, an intent filter). Offline, minutes. It turns
   16,024 opaque flips into a handful of semantic classes and shows which are
   security-relevant rather than cosmetic.
2. **Paired replay of the 93 healthy sample members** against the baseline,
   about three to four hours, to measure how often a healthy mutant diverges
   in behavior and whether the eight-action trace can see it.
3. **Full device pass** of all accepted flips, about 25 hours.

Recommended order: 1, then replay stratified by the classes it finds.
