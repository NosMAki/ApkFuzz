#!/usr/bin/env python3
"""Exhaustive one-bit enumeration of F-Droid's compressed manifest; see PROTOCOL.md.

Subcommands: enumerate (all flips, offline), crosscheck (against saved C-mutator
patches), sample (build a uniform sample in the live-sampler layout so the
unchanged offline analyzer can screen it). Outputs are created once.
"""

import argparse
import hashlib
import importlib.util
import json
import random
import struct
import sys
import zlib
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ORIGIN = ROOT / "Evaluation-SSBSE-2026/apk/F-Droid.apk"
SAMPLE_DIR = Path(str(HERE) + "-sample")
SAMPLE_SEED, SAMPLE_SIZE = 10436, 120


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


axml = load("enum_axml", ROOT / "scripts/android_binary_xml.py")
prepare = load("enum_prepare", ROOT / "scripts/prepare-manifest-runtime-candidate.py")


def now():
    return datetime.now(timezone.utc).isoformat()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def regions(data):
    pool = 8
    _, header, size = struct.unpack_from("<HHI", data, pool)
    count, _, _, strings_start, _ = struct.unpack_from("<IIIII", data, pool + 8)
    out = [("xml_header", 0, 8), ("strpool_header", pool, pool + header),
           ("strpool_offsets", pool + header, pool + header + 4 * count),
           ("strpool_data", pool + strings_start, pool + size)]
    cursor = pool + size
    kind, _, chunk = struct.unpack_from("<HHI", data, cursor)
    if kind == 0x0180:
        out.append(("resource_map", cursor, cursor + chunk))
        cursor += chunk
    out.append(("xml_nodes", cursor, len(data)))
    return out


def classify(compressed, usize, stored_crc):
    """Mirror manifest_crc() in strategies.c. Returns (class, decoded or None)."""
    stream = zlib.decompressobj(-15)
    try:
        decoded = stream.decompress(compressed, usize + 1)
    except zlib.error:
        return "deflate_error", None
    if not stream.eof:
        return ("length_changed" if len(decoded) > usize else "deflate_incomplete"), None
    if stream.unused_data:
        return "deflate_ends_early", None
    if len(decoded) != usize:
        return "length_changed", None
    if zlib.crc32(decoded) == stored_crc:
        return "content_unchanged", None
    reason = axml.structure_error(decoded)
    return ("accepted" if reason is None else f"structure:{reason}"), decoded


def context():
    original = ORIGIN.read_bytes()
    layout = prepare.manifest_layout(original)
    compressed = original[layout["data_start"]:layout["data_end"]]
    manifest = prepare.manifest_bytes(original, layout)
    if zlib.crc32(manifest) != layout["stored_crc32"]:
        raise SystemExit("origin manifest CRC mismatch")
    return original, layout, compressed, manifest


def enumerate_all(args):
    original, layout, compressed, manifest = context()
    usize, crc = layout["uncompressed_size"], layout["stored_crc32"]
    layout_regions = regions(manifest)
    region_of = lambda i: next((n for n, a, e in layout_regions if a <= i < e), "gap")
    counts, by_region, seen = Counter(), Counter(), {}
    rows = HERE / "enumeration.tsv"
    with open(rows, "x", encoding="utf-8") as out:
        out.write("offset\tbit\tclass\tdecoded_sha256\tchanged_bytes\tfirst_changed\tregions\n")
        work = bytearray(compressed)
        for index in range(len(compressed)):
            for bit in range(8):
                work[index] ^= 1 << bit
                kind, decoded = classify(bytes(work), usize, crc)
                work[index] ^= 1 << bit
                counts[kind] += 1
                extra = "\t\t\t"
                if decoded is not None:
                    changed = [i for i in range(usize) if decoded[i] != manifest[i]]
                    names = ",".join(sorted({region_of(i) for i in changed}))
                    digest = sha256(decoded)
                    extra = f"{digest}\t{len(changed)}\t{changed[0]}\t{names}"
                    if kind == "accepted":
                        by_region[names] += 1
                        seen.setdefault(digest, 0)
                        seen[digest] += 1
                out.write(f"{layout['data_start'] + index}\t{bit}\t{kind}\t{extra}\n")
    deflate_valid = sum(n for k, n in counts.items() if k == "accepted" or k.startswith("structure:"))
    summary = {"schema_version": 1, "generated_utc": now(), "origin_sha256": sha256(original),
               "origin_manifest_sha256": sha256(manifest), "compressed_bytes": len(compressed),
               "uncompressed_bytes": usize, "flips": 8 * len(compressed),
               "deflate_valid_changed": deflate_valid, "accepted": counts["accepted"],
               "accepted_distinct_manifests": len(seen), "classes": dict(sorted(counts.items())),
               "accepted_by_region": dict(sorted(by_region.items())),
               "manifest_regions": [{"name": n, "start": a, "end": e} for n, a, e in layout_regions],
               "rows": str(rows), "rows_sha256": sha256(rows.read_bytes()),
               "driver_sha256": sha256(Path(__file__).read_bytes()),
               "structure_check_sha256": sha256((ROOT / "scripts/android_binary_xml.py").read_bytes())}
    with open(HERE / "enumeration-summary.json", "x", encoding="utf-8") as out:
        json.dump(summary, out, indent=2)
        out.write("\n")
    print(json.dumps({k: summary[k] for k in ("flips", "deflate_valid_changed", "accepted",
                                              "accepted_distinct_manifests", "classes")}, indent=1))


def read_rows():
    table = {}
    with open(HERE / "enumeration.tsv", encoding="utf-8") as source:
        next(source)
        for line in source:
            offset, bit, kind, *_ = line.rstrip("\n").split("\t")
            table[(int(offset), int(bit))] = kind
    return table


def mutant_edits(original, layout, offset, bit):
    """Byte edits the mutator records: the flip, then changed CRC bytes (local, central)."""
    data = bytearray(original)
    data[offset] ^= 1 << bit
    edits = [(offset, original[offset], data[offset])]
    crc = zlib.crc32(prepare.manifest_bytes(bytes(data), layout))
    for i in range(4):
        new = (crc >> (8 * i)) & 0xFF
        for field in (layout["local_crc_offset"] + i, layout["central_crc_offset"] + i):
            if data[field] != new:
                edits.append((field, data[field], new))
                data[field] = new
    return bytes(data), edits


def crosscheck(args):
    original, layout, _, _ = context()
    table = read_rows()
    patch_tool = prepare.preflight.patch_tool
    in_stream = lambda off: layout["data_start"] <= off < layout["data_end"]
    report = {"schema_version": 1, "generated_utc": now(), "runs": {}}
    failures = []
    runs = {"axml-onebit-descendant-diagnostic-2026-11-15-10435": "accepted",
            "manifest-valid-onebit-local-30s-2026-11-12-10432": "deflate_valid",
            "manifest-valid-onebit-descendant-diagnostic-2026-11-12-10434": "deflate_valid",
            "fdroid-local-2h-2026-11-12-onebit-10420": "count_388"}
    for run, rule in runs.items():
        classes, checked = Counter(), 0
        for patch in sorted((ROOT / "results" / run / "patches").glob("*.patch")):
            head = patch.read_text(encoding="utf-8", errors="replace")
            if "\ngen 1\n" not in head or "\nparent " in head:
                continue
            _, meta, edits = patch_tool.read_patch(str(patch))
            flips = [(off, old ^ new) for off, old, new in edits if in_stream(off)]
            if len(flips) != 1 or flips[0][1].bit_count() != 1:
                failures.append(f"{run}/{patch.name}: not one compressed bit")
                continue
            offset, bit = flips[0][0], flips[0][1].bit_length() - 1
            kind = table[(offset, bit)]
            classes[kind] += 1
            checked += 1
            valid = kind == "accepted" or kind.startswith("structure:")
            if rule == "accepted":
                _, mine = mutant_edits(original, layout, offset, bit)
                if kind != "accepted" or sorted(mine) != sorted(edits):
                    failures.append(f"{run}/{patch.name}: {kind} or CRC edits differ")
            elif rule == "deflate_valid" and not valid:
                failures.append(f"{run}/{patch.name}: enumerated as {kind}")
        valid_count = sum(n for k, n in classes.items()
                          if k == "accepted" or k.startswith("structure:"))
        if rule == "count_388" and valid_count != 388:
            failures.append(f"{run}: {valid_count} deflate-valid of {checked}, expected 388")
        report["runs"][run] = {"rule": rule, "generation_one_patches": checked,
                               "deflate_valid": valid_count, "classes": dict(sorted(classes.items()))}
    report["failures"] = failures
    with open(HERE / "crosscheck.json", "x", encoding="utf-8") as out:
        json.dump(report, out, indent=2)
        out.write("\n")
    print(json.dumps(report, indent=1))
    return 1 if failures else 0


def sample(args):
    original, layout, _, _ = context()
    frame = sorted(key for key, kind in read_rows().items() if kind == "accepted")
    chosen = sorted(random.Random(SAMPLE_SEED).sample(frame, SAMPLE_SIZE))
    SAMPLE_DIR.mkdir()
    (SAMPLE_DIR / "patches").mkdir()
    rows = []
    for offset, bit in chosen:
        index = (offset - layout["data_start"]) * 8 + bit + 1
        data, edits = mutant_edits(original, layout, offset, bit)
        apk = SAMPLE_DIR / f"iter-{index:09d}-g1.apk"
        patch = SAMPLE_DIR / "patches" / f"F-Droid_enumerated_{index}.apk.patch"
        apk.write_bytes(data)
        patch.write_text(
            f"# apkfuzz-patch v2\norigin {ORIGIN}\nmode manifest-axml-onebit\nseed 0\n"
            f"iter {index}\ngen 1\nstatus ok\nedits {len(edits)}\n" +
            "".join(f"{off} {old:02x} {new:02x}\n" for off, old, new in edits))
        rows.append({"generation": 1, "iteration": index, "mutant_sha256": sha256(data),
                     "mutant_size": len(data), "mutator_seed": "enumerated",
                     "patch_path": str(patch), "patch_sha256": sha256(patch.read_bytes()),
                     "selection_method": "enumerated_uniform_sample", "status": "captured",
                     "flip_offset": offset, "flip_bit": bit, "stored_apk": str(apk)})
    (SAMPLE_DIR / "captures.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n"
                                                       for r in rows))
    (SAMPLE_DIR / "summary.json").write_text(json.dumps({
        "schema_version": 1, "generated_utc": now(),
        "source": "offline enumeration reconstruction; NOT an AFL live capture",
        "frame": "all enumerated accepted flips", "frame_size": len(frame),
        "sample_seed": SAMPLE_SEED, "sample_method": "random.Random(seed).sample, sorted frame",
        "stopped_by_file": True,  # field the analyzer requires of a finished sampler
        "counts": {"selected": len(rows), "captured": len(rows),
                   "captured_bytes": sum(r["mutant_size"] for r in rows)}}, indent=2) + "\n")
    print(f"frame {len(frame)}, sampled {len(rows)} into {SAMPLE_DIR}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("enumerate", "crosscheck", "sample"))
    args = parser.parse_args()
    return {"enumerate": enumerate_all, "crosscheck": crosscheck,
            "sample": sample}[args.command](args) or 0


if __name__ == "__main__":
    sys.exit(main())
