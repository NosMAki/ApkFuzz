# Semantic classification of accepted first-generation flips — method

Written 2026-11-15 before the classifier was run. Authorized by the user in
chat ("Classify flips by meaning"). Offline analysis of data already on disk;
no emulator, AFL, model, VM, or network use. No repository code is changed.

## Question

For each of the 16,024 accepted one-bit flips in
`results/gen1-enumeration-2026-11-15/enumeration.tsv`, what does it change in
the manifest as Android reads it: which element and attribute, from what to
what?

## Method

Parse the original and each mutated decoded manifest into the same model: the
ordered element tree, and for every attribute its identity and typed value.
Attribute identity is the resource ID from the manifest's resource map when
one exists (Android resolves framework attributes by ID, not by the name
string) and the name string otherwise. Line numbers, comments, raw-value
strings, and strings nothing refers to are outside the model. A flip is
`cosmetic` when the two models are equal. Otherwise every difference is
recorded and mapped to a class by the fixed table in `classify.py`, written
before any result was seen:

`package_identity`, `sdk_version`, `permission_declaration`,
`component_identity`, `component_exposure`, `app_security_flags`,
`intent_filter`, `metadata`, `features_queries`, `ui_or_behavior`,
`element_tag` (a tag renamed), `namespace_decl` (the declared XML namespace
changed; added before the first run), `tree_shape`, `other`.

A flip can touch several classes (a shared string is used in many places), so
class counts are not exclusive; the number touching exactly one class is
reported separately. The class names are my grouping for reading the results.
"Security-relevant" below means the mutant's manifest declares a different
exposure or permission; it is a property of the mutant, not a finding about
F-Droid.

## Validation

1. Parser: the original manifest's model must match Androguard's independent
   parse (element tags in order, attribute names per element, string and
   boolean values). The same comparison is run on every sampled mutant that
   Androguard can parse.
2. Predictions against the device results of the uniform sample
   (`results/gen1-enumeration-2026-11-15/sample-device-admission.json`),
   stated before classification:
   - every sampled flip classified `cosmetic` launched healthily;
   - each of the 5 sample members that failed the matched-pair check touches
     `package_identity`;
   - each of the 4 `launch_failed` members touches `intent_filter`,
     `component_identity`, or `element_tag`;
   - each of the 12 `launched_crashed` members touches
     `permission_declaration`, `component_identity`, or `element_tag`.
   A miss is reported as a classifier or model gap, not explained away.

## Limits

Static reading of one manifest; the model follows documented Android parsing
but is not Android's parser. Device outcomes exist only for the 120-member
sample. Generation one only.
