# What the accepted first-generation flips change — 2026-11-15

## Conclusion

Each of the 16,024 accepted one-bit flips was classified by what it changes in
the manifest. About a quarter change nothing an attribute or tag carries, a
fifth change exactly one thing, and half change several things at once.

| Group | Flips | Share |
| --- | ---: | ---: |
| No tag, attribute identity, or typed value differs (`cosmetic` by the model) | 4,528 | 28.3% |
| Exactly one difference | 3,247 | 20.3% |
| Two to five differences | 3,849 | 24.0% |
| Six or more differences | 4,400 | 27.5% |

Three of the four predictions written before classification held on the device
sample; the fourth missed by one case, which exposed a real gap in the model
(raw attribute values, below). No result here is an F-Droid defect.

## Scope and method

Authorized by the user in chat ("Classify flips by meaning"). Offline only: no
emulator, AFL, model, VM, or network use, and no repository code changed
(`git status --short` still 84 entries). Inputs are
`results/gen1-enumeration-2026-11-15/enumeration.tsv` and that step's sample
and device results. Method and class table: [PROTOCOL.md](PROTOCOL.md).

```bash
.venv-llmdroid/bin/python -B results/gen1-flip-semantics-2026-11-15/validate_parser.py  # exit 0
python3 -B results/gen1-flip-semantics-2026-11-15/classify.py classify                  # exit 0
python3 -B results/gen1-flip-semantics-2026-11-15/queries.py                            # exit 0
python3 -B results/gen1-flip-semantics-2026-11-15/refine_cosmetic.py                    # exit 0, post-hoc
```

## Parser validation

The model of the original manifest (321 elements, 497 attributes) matches
Androguard 4.1.4's independent parse exactly: same tags in order, same
attribute names per element, and all 426 string and boolean values equal.

On the 120 sampled mutants, 82 match, 37 differ, and Androguard failed on 1.
In the 12 differing cases inspected, the cause was a difference in *how the
two readers resolve the same bytes*, not a parsing error: Androguard takes an
attribute's name from its name string and namespace string (the model uses
the resource ID), reads the raw value index, truncates strings at an embedded
NUL, and replaces invalid tag characters. The remaining 25 were grouped
automatically (value differences 27, attribute-name differences 5, tag
differences 5) but not read individually.

## What the flips touch

A flip counts once in every class it touches, so these overlap.

| Class | Flips touching it | Flips touching only it |
| --- | ---: | ---: |
| Intent filter (action, category, data) | 5,572 | 1,734 |
| Component identity (class names) | 5,514 | 2,149 |
| `cosmetic` | 4,528 | 4,528 |
| Permission declaration | 2,851 | 879 |
| Component exposure | 1,839 | 121 |
| UI or behavior attributes | 1,825 | 325 |
| Element tag renamed | 1,532 | 340 |
| Features and queries | 1,276 | 331 |
| Meta-data | 1,084 | 75 |
| Package identity | 812 | 197 |
| Application security flags | 614 | 34 |
| Namespace declaration | 542 | 44 |
| SDK version | 45 | 20 |
| Tree shape | 1 | 1 |

Multi-site flips are common for two reasons: deflate copies a changed byte into
every later place that referred back to it, and one string (a tag name, a
package prefix) is used by many elements.

**Single-difference flips (3,247)** are the cleanest candidates for a
behavioral test, since any divergence has one cause. Largest sites:
`activity@name` 531, `action@name` 482, `uses-permission@name` 393 (416 across
all permission tags, covering 27 distinct permissions), `receiver@name` 368,
`service@name` 353, `uses-feature@name` 151, `data@pathPattern` 132,
`data@scheme` 83, `data@path` 68, `data@host` 60. Smaller but
security-relevant: `provider@authorities` 11, `service@enabled` 9,
`application@networkSecurityConfig` 3, `application@appComponentFactory` 22,
and removal of `extractNativeLibs` (2), `allowBackup` (1),
`requestLegacyExternalStorage` (1), `dataExtractionRules` (1).

**What this operator rarely does.** No flip, alone or with others, cleanly
toggles `android:exported` between true and false; only two flips toggle any
tracked boolean (`enabled`). `exported` is touched in 127 flips, component
`permission` guards in 1,204, and `provider@authorities` in 1,131, but
almost always inside multi-site changes. `debuggable` and
`usesCleartextTraffic` are never touched (the manifest does not declare them).
One-bit changes to the compressed stream mostly rewrite strings; they are a
poor way to explore exposure flags, which would need mutation of the decoded
manifest instead.

## Prediction check on the device sample

| Prediction (written before classification) | Result |
| --- | --- |
| Every sampled `cosmetic` flip launched healthily | 42 of 43; **1 miss** |
| The 5 pair-check failures touch package identity | 5 of 5 |
| The 4 launch failures touch intent filter, component identity, or a tag | 3 of 4; same miss |
| The 12 start-up crashes touch a permission, component identity, or a tag | 12 of 12 |

Device outcome by number of differences: `cosmetic` 42 healthy of 43; one
difference 17 healthy of 20 (2 blocked offline on package identity, 1 install
failure from a control character in a MIME type); several differences 34
healthy of 57 (12 crashes, 5 install failures, 3 launch failures, 3 blocked).

### The miss, and the model gap it exposed

The missed flip changed only the *raw value* string index of a `<category>`
name from `android.intent.category.LAUNCHER` to another string, leaving the
typed value pointing at `LAUNCHER`. The model reads the typed value, so it
called the flip cosmetic; on the device the launcher intent no longer
resolved. Android therefore reads at least that attribute through its raw
value. This is a single observation on Android 10.

A refinement added afterward (`refine_cosmetic.py`; original outputs
untouched) splits the 4,528:

| Subclass | Flips | Sample: healthy |
| --- | ---: | --- |
| `inert`: no attribute field differs | 3,339 | 33 of 33 |
| `raw_value_only`: raw string index no longer equals typed index | 1,123 | 9 of 10 |
| `attr_namespace_only`: an attribute's namespace index differs | 66 | none sampled |

Raw-only sites: `action@name` 201, `uses-permission@name` 147,
`data@pathPattern` 139, `activity@name` 101, `receiver@name` 74,
`service@name` 74, `data@scheme` 73, `data@host` 59, `category@name` 33,
`provider@authorities` 24.

In all 10 sampled raw-only mutants Androguard reported a value different from
the typed one, and 9 of them still launched normally. So for 1,123 one-bit
mutants the manifest carries two different values for the same attribute, and
which one a reader sees depends on the reader. That is a parser-disagreement
population, and Androguard is the parser LLMDroid uses. What Android itself
read for each of those attributes was not observed directly.

## Interpretation

1. The space divides usefully: 3,339 inert flips are natural negative
   controls, 3,247 single-difference flips are attributable test cases, and
   1,123 raw-only flips are a separate question about reader disagreement.
2. Most semantic change is renaming: class names, actions, permission names.
   A renamed permission or component is what produced the start-up crashes
   seen on the device, so many of these mutants will diverge trivially.
3. The operator is not a way to study exposure changes such as `exported`.

## Limits

- The model is a static reading and, as the miss shows, not Android's parser.
  The typed-versus-raw behavior of other attributes is unmeasured.
- Device outcomes exist for 120 sampled flips only; class-level healthy rates
  from that sample are small-number descriptions.
- Class names and the "security-relevant" label are my grouping. A mutant that
  declares a different permission or authority is a test input, not a finding
  about F-Droid.
- `classification.tsv` stores the first six differences per flip; per-attribute
  kinds for multi-site flips need `queries.py`-style recomputation.
- One app, generation one.

## Evidence (SHA-256)

- `PROTOCOL.md` `530c0666fef6769a78a85da721fd8a00d509419b6a0e8e12600ddc945713fbed`
- `classify.py` `197238281b639235a0a5b223848a73531ced6bfe8ef2ed534371f93d1101343f`
- `queries.py` `0a5c3e79315f2a2a3c8aa1b15ff32528ec670ee83db96c48072b981fb16a0142`
- `refine_cosmetic.py` `3eef16e86d84232ce9dc56389e4b581368b2b00db937054ed2ddc52542a0d7b2`
- `validate_parser.py` `836cb552330b3d70ef47c5f75004d857b4af5a1e91b8e89c2c3fe45f506a8518`
- `classification.tsv` `5370003a97ecadb853dfd0aae47d52778c0bb9bf990ec5aba3b45b1a2452989e`
- `classification-summary.json` `831890614681045fbc0d7d678e06dd07cd5b0ccb430bb3738978484a1fcd8c1a`
- `queries.json` `017bda45b2c557ba7676599c12fe353c9cee325f8962451ddb67a00393824ee3`
- `cosmetic-refinement.tsv` `596e9b2feec299cca693eec2d55023643d74be106a57f60e6a0fd8f42ef876df`
- `cosmetic-refinement.json` `cdbadb60cc227b145eaf1b91a2a65cc7581cfdb406e07c9b928c93d078cede5f`
- `parser-validation.json` `a1d77dd974caee48375c3350a080f8ecb2f78b355520bb9221076fdd7d4e4165`

## Next experiment (not started)

Two candidates, both bounded:

1. **Stratified paired replay.** About 100 pairs drawn by class from the
   single-difference flips, with inert flips as negative controls (they should
   show no divergence) and the known start-up crasher as a positive control.
   Roughly three to four hours of emulator time. Measures how often an
   attributable manifest change produces a behavioral divergence that the
   eight-action trace can see.
2. **Reader-disagreement study of the raw-only flips.** For a sample of the
   1,123, record the value reported by `aapt`, Androguard, and Android's own
   package manager (`dumpsys package` after install) for the affected
   attribute. Under an hour. Establishes which readers disagree with Android,
   which matters directly for any analysis that trusts a static parser.
