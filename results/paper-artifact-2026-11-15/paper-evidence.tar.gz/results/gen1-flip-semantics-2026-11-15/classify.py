#!/usr/bin/env python3
"""Classify accepted one-bit manifest flips by what they change; see PROTOCOL.md.

Subcommands: model (dump the model of one APK's manifest as JSON, for the
independent parser comparison) and classify (all accepted flips).
"""

import argparse
import importlib.util
import json
import struct
import sys
import zipfile
import zlib
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ENUM = ROOT / "results/gen1-enumeration-2026-11-15"
ORIGIN = ROOT / "Evaluation-SSBSE-2026/apk/F-Droid.apk"
NO = 0xFFFFFFFF
TYPE_STRING, TYPE_BOOLEAN = 0x03, 0x12
COMPONENTS = ("application", "activity", "activity-alias", "service", "receiver", "provider")

# ---- fixed class table (written before any result was inspected) ----
TAG_CLASS = {
    "uses-permission": "permission_declaration", "uses-permission-sdk-23": "permission_declaration",
    "permission": "permission_declaration", "permission-group": "permission_declaration",
    "permission-tree": "permission_declaration",
    "uses-sdk": "sdk_version", "manifest": "package_identity",
    "intent-filter": "intent_filter", "action": "intent_filter", "category": "intent_filter",
    "data": "intent_filter", "meta-data": "metadata",
    "uses-feature": "features_queries", "supports-screens": "features_queries",
    "uses-library": "features_queries", "uses-native-library": "features_queries",
    "uses-configuration": "features_queries", "queries": "features_queries",
    "package": "features_queries", "intent": "features_queries",
    "grant-uri-permission": "component_exposure", "path-permission": "component_exposure",
}
EXPOSURE_ATTRS = {"exported", "permission", "readPermission", "writePermission", "enabled",
                  "grantUriPermissions", "authorities", "directBootAware", "process",
                  "isolatedProcess", "multiprocess", "syncable", "visibleToInstantApps"}
IDENTITY_ATTRS = {"name", "targetActivity"}
APP_FLAG_ATTRS = {"debuggable", "allowBackup", "usesCleartextTraffic", "networkSecurityConfig",
                  "requestLegacyExternalStorage", "extractNativeLibs", "testOnly",
                  "fullBackupContent", "fullBackupOnly", "backupAgent", "allowClearUserData",
                  "hasCode", "dataExtractionRules", "appComponentFactory",
                  "allowNativeHeapPointerTagging", "preserveLegacyExternalStorage"}


def class_of(tag, attr):
    if tag in TAG_CLASS:
        return TAG_CLASS[tag]
    if tag in COMPONENTS:
        short = attr.split(":")[-1]
        if short in EXPOSURE_ATTRS:
            return "component_exposure"
        if short in IDENTITY_ATTRS:
            return "component_identity"
        if short in APP_FLAG_ATTRS:
            return "app_security_flags"
        return "ui_or_behavior"
    return "other"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def u16(data, offset):
    return struct.unpack_from("<H", data, offset)[0]


def u32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def parse(data):
    """Parse a structurally valid binary XML manifest.

    Returns (strings, resource_map, elements, namespaces). An element is
    {"tag", "depth", "parent", "attrs": [(ns_idx, name_idx, type, data)]} with
    indices left unresolved so two documents can be compared exactly.
    """
    pool = 8
    pool_size = u32(data, pool + 4)
    count, _, flags, strings_start, _ = struct.unpack_from("<IIIII", data, pool + 8)
    base = pool + strings_start
    strings = []
    for index in range(count):
        off = base + u32(data, pool + 28 + 4 * index)
        if flags & 0x100:
            for _ in range(2):
                length = data[off]
                off += 1
                if length & 0x80:
                    length = ((length & 0x7F) << 8) | data[off]
                    off += 1
            strings.append(data[off:off + length].decode("utf-8", "replace"))
        else:
            length = u16(data, off)
            off += 2
            if length & 0x8000:
                length = ((length & 0x7FFF) << 16) | u16(data, off)
                off += 2
            strings.append(data[off:off + 2 * length].decode("utf-16-le", "replace"))
    cursor = pool + pool_size
    resource_map, elements, stack, namespaces = [], [], [], []
    while cursor < len(data):
        kind, header, chunk = u16(data, cursor), u16(data, cursor + 2), u32(data, cursor + 4)
        if kind == 0x0180:
            resource_map = [u32(data, cursor + header + 4 * i)
                            for i in range((chunk - header) // 4)]
        elif kind == 0x0100:
            namespaces.append((u32(data, cursor + 16), u32(data, cursor + 20)))
        elif kind == 0x0102:
            ext = cursor + 16
            start, size, number = u16(data, ext + 8), u16(data, ext + 10), u16(data, ext + 12)
            attrs = []
            for index in range(number):
                attr = ext + start + index * size
                attrs.append((u32(data, attr), u32(data, attr + 4), data[attr + 15],
                              u32(data, attr + 16)))
            elements.append({"tag": u32(data, ext + 4), "depth": len(stack),
                             "parent": stack[-1] if stack else None, "attrs": attrs})
            stack.append(len(elements) - 1)
        elif kind == 0x0103:
            stack.pop()
        cursor += chunk
    return strings, resource_map, elements, namespaces


class Model:
    """Manifest as Android reads it: tags, attribute identities, typed values."""

    def __init__(self, data, attr_names=None):
        self.strings, self.resource_map, raw, spaces = parse(data)
        self.namespaces = [(self.strings[p] if p != NO else "", self.strings[u])
                           for p, u in spaces]
        # Framework attribute names are taken from the ORIGINAL manifest's
        # resource map so an ID keeps its meaning when its name string changes.
        self.attr_names = attr_names if attr_names is not None else {
            rid: self.strings[i] for i, rid in enumerate(self.resource_map) if rid}
        self.elements = []
        for item in raw:
            attrs = {}
            for ns, name, kind, value in item["attrs"]:
                rid = self.resource_map[name] if name < len(self.resource_map) else 0
                if rid:
                    key = "android:" + self.attr_names.get(rid, f"@0x{rid:08x}")
                else:
                    prefix = "" if ns == NO else self.strings[ns] + "|"
                    key = prefix + self.strings[name]
                attrs[key] = self.value(kind, value)
            parent = self.elements[item["parent"]]["tag"] if item["parent"] is not None else None
            self.elements.append({"tag": self.strings[item["tag"]], "depth": item["depth"],
                                  "parent": parent, "parent_index": item["parent"],
                                  "attrs": attrs})

    def value(self, kind, value):
        if kind == TYPE_STRING:
            return ("string", self.strings[value])
        if kind == TYPE_BOOLEAN:
            return ("bool", value != 0)
        return (f"type0x{kind:02x}", value)

    def component(self, index):
        """Original-style label of the nearest enclosing component."""
        while index is not None:
            element = self.elements[index]
            if element["tag"] in COMPONENTS:
                name = element["attrs"].get("android:name", ("", ""))[1]
                return f"{element['tag']}:{name}"
            index = element["parent_index"]
        return ""

    def shape(self):
        return [(e["depth"], len(e["attrs"])) for e in self.elements]

    def to_json(self):
        return [{"tag": e["tag"], "depth": e["depth"],
                 "attrs": {k: list(v) for k, v in sorted(e["attrs"].items())}}
                for e in self.elements]


def show(value):
    if value is None:
        return "(absent)"
    kind, data = value
    if kind == "string":
        return data
    if kind == "bool":
        return "true" if data else "false"
    return f"{kind}:0x{data:08x}"


def differences(original, mutated):
    """List of (class, tag, attribute, old, new, kind, component)."""
    if [e["depth"] for e in original.elements] != [e["depth"] for e in mutated.elements]:
        return [("tree_shape", "", "", str(len(original.elements)),
                 str(len(mutated.elements)), "tree_shape", "")]
    out = []
    if original.namespaces != mutated.namespaces:
        out.append(("namespace_decl", "", "xmlns", str(original.namespaces),
                    str(mutated.namespaces), "namespace_changed", ""))
    for index, (old, new) in enumerate(zip(original.elements, mutated.elements)):
        component = original.component(index)
        if old["tag"] != new["tag"]:
            out.append(("element_tag", old["tag"], "", old["tag"], new["tag"],
                        "tag_renamed", component))
        for key in sorted(set(old["attrs"]) | set(new["attrs"])):
            before, after = old["attrs"].get(key), new["attrs"].get(key)
            if before == after:
                continue
            kind = ("value_changed" if before is not None and after is not None else
                    "attribute_removed" if after is None else "attribute_added")
            out.append((class_of(old["tag"], key), old["tag"], key, show(before), show(after),
                        kind, component))
    return out


def manifest_of(path):
    with zipfile.ZipFile(path) as archive:
        return archive.read("AndroidManifest.xml")


def model_command(args):
    original = Model(manifest_of(ORIGIN))
    model = Model(manifest_of(args.apk), original.attr_names)
    json.dump(model.to_json(), sys.stdout)


def classify_command(args):
    prepare = load("sem_prepare", ROOT / "scripts/prepare-manifest-runtime-candidate.py")
    raw = ORIGIN.read_bytes()
    layout = prepare.manifest_layout(raw)
    compressed = bytearray(raw[layout["data_start"]:layout["data_end"]])
    original_bytes = prepare.manifest_bytes(raw, layout)
    original = Model(original_bytes)
    counts, exclusive, pairs, kinds = Counter(), Counter(), Counter(), Counter()
    cosmetic_regions, sites = Counter(), Counter()
    rows_path = HERE / "classification.tsv"
    total = 0
    with open(ENUM / "enumeration.tsv", encoding="utf-8") as source, \
            open(rows_path, "x", encoding="utf-8") as out:
        next(source)
        out.write("offset\tbit\tclasses\tsites\tdecoded_regions\tdifferences\n")
        for line in source:
            offset, bit, kind, _, _, _, regions = line.rstrip("\n").split("\t")
            if kind != "accepted":
                continue
            index = int(offset) - layout["data_start"]
            compressed[index] ^= 1 << int(bit)
            decoded = zlib.decompress(bytes(compressed), -15)
            compressed[index] ^= 1 << int(bit)
            diffs = differences(original, Model(decoded, original.attr_names))
            classes = sorted({d[0] for d in diffs}) or ["cosmetic"]
            total += 1
            for name in classes:
                counts[name] += 1
            if len(classes) == 1:
                exclusive[classes[0]] += 1
            if not diffs:
                cosmetic_regions[regions] += 1
            sites["1" if len(diffs) == 1 else "0" if not diffs else
                  "2-5" if len(diffs) <= 5 else "6+"] += 1
            for d in diffs:
                kinds[d[5]] += 1
            for pair in {(d[0], f"{d[1]}@{d[2]}" if d[2] else f"<{d[1]}>") for d in diffs}:
                pairs[pair] += 1
            text = json.dumps([list(d) for d in diffs[:6]], ensure_ascii=True)
            out.write(f"{offset}\t{bit}\t{','.join(classes)}\t{len(diffs)}\t{regions}\t{text}\n")
    summary = {"schema_version": 1, "generated_utc": datetime.now(timezone.utc).isoformat(),
               "accepted_flips": total, "elements": len(original.elements),
               "attributes": sum(len(e["attrs"]) for e in original.elements),
               "flips_touching_class": dict(counts.most_common()),
               "flips_touching_only_class": dict(exclusive.most_common()),
               "difference_kinds": dict(kinds.most_common()),
               "sites_per_flip": dict(sites), "cosmetic_by_decoded_region": dict(cosmetic_regions),
               "flips_by_class_and_site": [[c, s, n] for (c, s), n in pairs.most_common()]}
    with open(HERE / "classification-summary.json", "x", encoding="utf-8") as out:
        json.dump(summary, out, indent=2)
        out.write("\n")
    print(json.dumps({k: summary[k] for k in ("accepted_flips", "elements", "attributes",
                                              "flips_touching_class", "flips_touching_only_class",
                                              "difference_kinds", "sites_per_flip",
                                              "cosmetic_by_decoded_region")}, indent=1))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    model = sub.add_parser("model")
    model.add_argument("apk", type=Path)
    sub.add_parser("classify")
    args = parser.parse_args()
    return {"model": model_command, "classify": classify_command}[args.command](args) or 0


if __name__ == "__main__":
    sys.exit(main())
