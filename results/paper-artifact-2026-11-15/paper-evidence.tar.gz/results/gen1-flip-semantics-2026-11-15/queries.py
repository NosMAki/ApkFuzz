#!/usr/bin/env python3
"""Second pass over the accepted flips: prediction check against the device
sample and counts of exposure- and permission-related changes. See PROTOCOL.md."""

import importlib.util
import json
import zlib
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("classify", HERE / "classify.py")
classify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(classify)
ENUM = classify.ENUM
BOOL_FLAGS = ("exported", "enabled", "grantUriPermissions", "debuggable", "allowBackup",
              "usesCleartextTraffic", "requestLegacyExternalStorage", "extractNativeLibs",
              "testOnly", "hasCode", "directBootAware")
GUARDS = ("permission", "readPermission", "writePermission")


def all_differences():
    prepare = classify.load("q_prepare", classify.ROOT / "scripts/prepare-manifest-runtime-candidate.py")
    raw = classify.ORIGIN.read_bytes()
    layout = prepare.manifest_layout(raw)
    compressed = bytearray(raw[layout["data_start"]:layout["data_end"]])
    original = classify.Model(prepare.manifest_bytes(raw, layout))
    with open(ENUM / "enumeration.tsv", encoding="utf-8") as source:
        next(source)
        for line in source:
            offset, bit, kind, *_ = line.rstrip("\n").split("\t")
            if kind != "accepted":
                continue
            index = int(offset) - layout["data_start"]
            compressed[index] ^= 1 << int(bit)
            decoded = zlib.decompress(bytes(compressed), -15)
            compressed[index] ^= 1 << int(bit)
            yield (int(offset), int(bit)), classify.differences(
                original, classify.Model(decoded, original.attr_names))


def main():
    sample = {}
    for line in open(str(ENUM) + "-sample/captures.jsonl"):
        row = json.loads(line)
        sample[(row["flip_offset"], row["flip_bit"])] = row
    analysis = {c["iteration"]: c for c in
                json.load(open(str(ENUM) + "-analysis/analysis.json"))["candidates"]}
    device = {a["tested_apk_sha256"]: a["classification"] for a in
              json.load(open(ENUM / "sample-device-admission.json"))["attempts"]
              if a["kind"] == "cohort"}
    single_site, single_flag, any_flag = Counter(), Counter(), Counter()
    single_guard, single_perm, single_sdk = Counter(), Counter(), Counter()
    examples = defaultdict(list)
    sample_rows = []
    for key, diffs in all_differences():
        classes = sorted({d[0] for d in diffs}) or ["cosmetic"]
        single = len(diffs) == 1
        for cls, tag, attr, old, new, kind, component in diffs:
            short = attr.split(":")[-1]
            if short in BOOL_FLAGS and kind == "value_changed" and {old, new} == {"true", "false"}:
                label = f"{tag}@{short} {old}->{new}"
                any_flag[label] += 1
                if single:
                    single_flag[label] += 1
                    if len(examples[label]) < 3:
                        examples[label].append({"offset": key[0], "bit": key[1],
                                                "component": component})
        if single:
            cls, tag, attr, old, new, kind, component = diffs[0]
            short = attr.split(":")[-1]
            single_site[(cls, f"{tag}@{attr}" if attr else f"<{tag}>", kind)] += 1
            if tag in classify.COMPONENTS and short in GUARDS:
                single_guard[f"{tag}@{short} {kind}"] += 1
                if len(examples["guard"]) < 4:
                    examples["guard"].append({"offset": key[0], "bit": key[1],
                                              "component": component, "old": old, "new": new})
            if tag.startswith("uses-permission") and short == "name":
                single_perm[old] += 1
            if tag == "uses-sdk":
                single_sdk[f"{short} {old}->{new}"] += 1
        if key in sample:
            member = analysis[sample[key]["iteration"]]
            outcome = (device.get(member.get("prepared_sha256"))
                       if member["admission"] == "ready_for_install_attempt"
                       else "blocked_offline_pair_check")
            sample_rows.append({"offset": key[0], "bit": key[1], "classes": classes,
                                "sites": len(diffs), "outcome": outcome,
                                "first": list(diffs[0][:6]) if diffs else None})

    def touches(row, *names):
        return any(name in row["classes"] for name in names)

    predictions = {
        "cosmetic_all_healthy": [r for r in sample_rows if r["classes"] == ["cosmetic"] and
                                 r["outcome"] != "launched_process_running"],
        "pair_blocked_touch_package_identity": [
            r for r in sample_rows if r["outcome"] == "blocked_offline_pair_check" and
            not touches(r, "package_identity")],
        "launch_failed_touch_filter_identity_or_tag": [
            r for r in sample_rows if r["outcome"] == "launch_failed" and
            not touches(r, "intent_filter", "component_identity", "element_tag")],
        "crashed_touch_permission_identity_or_tag": [
            r for r in sample_rows if r["outcome"] == "launched_crashed" and
            not touches(r, "permission_declaration", "component_identity", "element_tag")],
    }
    by_sites = Counter((("cosmetic" if not r["sites"] else "one_site" if r["sites"] == 1
                         else "multi_site"), r["outcome"]) for r in sample_rows)
    by_class = Counter((cls, r["outcome"] == "launched_process_running")
                       for r in sample_rows for cls in r["classes"])
    report = {
        "schema_version": 1, "generated_utc": datetime.now(timezone.utc).isoformat(),
        "sample_members": len(sample_rows),
        "prediction_misses": {k: v for k, v in predictions.items()},
        "sample_outcome_by_sites": [[a, b, n] for (a, b), n in sorted(by_sites.items())],
        "sample_healthy_by_class": [[c, h, n] for (c, h), n in sorted(by_class.items())],
        "single_site_flips": sum(single_site.values()),
        "single_site_by_class_site_kind": [[c, s, k, n] for (c, s, k), n in single_site.most_common()],
        "boolean_flag_changes_single_site": dict(single_flag.most_common()),
        "boolean_flag_changes_any_flip": dict(any_flag.most_common()),
        "component_guard_changes_single_site": dict(single_guard.most_common()),
        "uses_permission_renamed_single_site": dict(single_perm.most_common()),
        "uses_sdk_changes_single_site": dict(single_sdk.most_common()),
        "examples": examples, "sample_rows": sample_rows}
    with open(HERE / "queries.json", "x", encoding="utf-8") as out:
        json.dump(report, out, indent=2)
        out.write("\n")
    for name in ("sample_members", "sample_outcome_by_sites", "sample_healthy_by_class",
                 "single_site_flips", "boolean_flag_changes_single_site",
                 "boolean_flag_changes_any_flip", "component_guard_changes_single_site",
                 "uses_sdk_changes_single_site"):
        print(name, json.dumps(report[name]))
    print("uses_permission_renamed_single_site", len(single_perm), "permissions,",
          sum(single_perm.values()), "flips")
    for name, misses in predictions.items():
        print("prediction", name, "misses:", len(misses), json.dumps(misses)[:500])
    top = Counter()
    for (cls, site, kind), n in single_site.items():
        top[(cls, kind)] += n
    print("single_site by class/kind", json.dumps([[c, k, n] for (c, k), n in top.most_common()]))


if __name__ == "__main__":
    main()
