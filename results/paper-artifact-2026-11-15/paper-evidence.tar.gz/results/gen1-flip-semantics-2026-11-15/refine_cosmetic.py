#!/usr/bin/env python3
"""Post-hoc refinement of the `cosmetic` class, added after one prediction miss.

The pre-registered model ignores an attribute's raw-value string index. One
sampled flip that changed only that index on a <category> name failed to
launch, so `cosmetic` is split here into: raw_value_only (a string attribute
whose raw index no longer equals its typed index), attr_namespace_only, and
inert (no attribute field differs). The original outputs are left unchanged.
"""
import importlib.util
import json
import struct
import zlib
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("classify", HERE / "classify.py")
classify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(classify)


def attributes(data):
    out, cursor = [], 8 + struct.unpack_from("<I", data, 12)[0]
    while cursor < len(data):
        kind, _, chunk = struct.unpack_from("<HHI", data, cursor)
        if kind == 0x0102:
            ext = cursor + 16
            tag = struct.unpack_from("<I", data, ext + 4)[0]
            start, size, count = struct.unpack_from("<HHH", data, ext + 8)
            for index in range(count):
                ns, name, raw, _, _, kind_, value = struct.unpack_from(
                    "<IIIHBBI", data, ext + start + index * size)
                out.append((tag, ns, name, raw, kind_, value))
        cursor += chunk
    return out


def main():
    prepare = classify.load("r_prepare", classify.ROOT / "scripts/prepare-manifest-runtime-candidate.py")
    raw = classify.ORIGIN.read_bytes()
    layout = prepare.manifest_layout(raw)
    compressed = bytearray(raw[layout["data_start"]:layout["data_end"]])
    original_bytes = prepare.manifest_bytes(raw, layout)
    original = classify.Model(original_bytes)
    base = attributes(original_bytes)
    sample = {}
    for line in open(str(classify.ENUM) + "-sample/captures.jsonl"):
        row = json.loads(line)
        sample[(row["flip_offset"], row["flip_bit"])] = row["iteration"]
    analysis = {c["iteration"]: c for c in
                json.load(open(str(classify.ENUM) + "-analysis/analysis.json"))["candidates"]}
    device = {a["tested_apk_sha256"]: a["classification"] for a in
              json.load(open(classify.ENUM / "sample-device-admission.json"))["attempts"]
              if a["kind"] == "cohort"}
    androguard = json.load(open(HERE / "parser-validation.json"))["sample"]
    counts, raw_sites, sample_rows = Counter(), Counter(), []
    with open(HERE / "classification.tsv", encoding="utf-8") as source, \
            open(HERE / "cosmetic-refinement.tsv", "x", encoding="utf-8") as out:
        next(source)
        out.write("offset\tbit\tsubclass\traw_value_sites\n")
        for line in source:
            offset, bit, classes, *_ = line.rstrip("\n").split("\t")
            if classes != "cosmetic":
                continue
            offset, bit = int(offset), int(bit)
            index = offset - layout["data_start"]
            compressed[index] ^= 1 << bit
            mutated = attributes(zlib.decompress(bytes(compressed), -15))
            compressed[index] ^= 1 << bit
            sites = sorted({f"{original.strings[o[0]]}@{original.strings[o[2]]}"
                            for o, m in zip(base, mutated) if o[3] != m[3]})
            if sites:
                subclass = "raw_value_only"
                for site in sites:
                    raw_sites[site] += 1
            elif any(o[1] != m[1] for o, m in zip(base, mutated)):
                subclass = "attr_namespace_only"
            else:
                subclass = "inert"
            counts[subclass] += 1
            out.write(f"{offset}\t{bit}\t{subclass}\t{','.join(sites)}\n")
            if (offset, bit) in sample:
                iteration = sample[(offset, bit)]
                sample_rows.append({
                    "offset": offset, "bit": bit, "subclass": subclass, "sites": sites,
                    "device": device.get(analysis[iteration].get("prepared_sha256")),
                    "androguard_vs_typed_model": androguard[str(iteration)]["status"]})
    table = Counter((r["subclass"], r["device"], r["androguard_vs_typed_model"])
                    for r in sample_rows)
    report = {"schema_version": 1, "generated_utc": datetime.now(timezone.utc).isoformat(),
              "cosmetic_flips": sum(counts.values()), "subclasses": dict(counts),
              "raw_value_sites": dict(raw_sites.most_common()),
              "sample_subclass_device_androguard": [[a, b, c, n] for (a, b, c), n
                                                    in sorted(table.items(), key=str)],
              "sample_rows": sample_rows}
    with open(HERE / "cosmetic-refinement.json", "x", encoding="utf-8") as out:
        json.dump(report, out, indent=2)
        out.write("\n")
    print(json.dumps({k: report[k] for k in ("cosmetic_flips", "subclasses",
                                             "sample_subclass_device_androguard")}, indent=1))
    print(json.dumps(dict(raw_sites.most_common(12))))


if __name__ == "__main__":
    main()
