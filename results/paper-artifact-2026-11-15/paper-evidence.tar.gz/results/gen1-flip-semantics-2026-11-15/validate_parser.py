#!/usr/bin/env python3
"""Compare classify.py's manifest model with Androguard's independent parse.

Run with the LLMDroid interpreter. Compares element tags in document order,
attribute names per element, and string/boolean values.
"""
import importlib.util
import json
import logging
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("classify", HERE / "classify.py")
classify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(classify)
ANDROID = "{http://schemas.android.com/apk/res/android}"


def compare(path, names):
    from androguard.core.apk import APK
    try:
        root = APK(str(path)).get_android_manifest_xml()
        theirs = [(e.tag, dict(e.attrib)) for e in root.iter() if isinstance(e.tag, str)]
    except Exception as exc:
        return {"status": "androguard_error", "error": type(exc).__name__}
    mine = classify.Model(classify.manifest_of(path), names).elements
    if [e["tag"] for e in mine] != [tag for tag, _ in theirs]:
        return {"status": "tags_differ"}
    names_differ = values_differ = values = 0
    for element, (_, attrs) in zip(mine, theirs):
        other = {("android:" + k[len(ANDROID):] if k.startswith(ANDROID) else k): v
                 for k, v in attrs.items()}
        if set(element["attrs"]) != set(other):
            names_differ += 1
            continue
        for key, (kind, value) in element["attrs"].items():
            if kind in ("string", "bool"):
                values += 1
                expected = value if kind == "string" else ("true" if value else "false")
                values_differ += other[key] != expected
    return {"status": "match" if not names_differ and not values_differ else "differs",
            "elements": len(mine), "elements_with_other_attribute_names": names_differ,
            "values_compared": values, "values_differ": values_differ}


def main():
    try:
        from loguru import logger
        logger.remove()
    except ImportError:
        pass
    logging.disable(logging.CRITICAL)
    names = classify.Model(classify.manifest_of(classify.ORIGIN)).attr_names
    report = {"origin": compare(classify.ORIGIN, names), "sample": {}}
    counts = {}
    for line in open(classify.ENUM.parent / "gen1-enumeration-2026-11-15-sample/captures.jsonl"):
        row = json.loads(line)
        result = compare(row["stored_apk"], names)
        report["sample"][str(row["iteration"])] = result
        counts[result["status"]] = counts.get(result["status"], 0) + 1
    report["sample_counts"] = counts
    with open(HERE / "parser-validation.json", "x") as out:
        json.dump(report, out, indent=2)
        out.write("\n")
    print(json.dumps({"origin": report["origin"], "sample_counts": counts}))
    return 0 if report["origin"]["status"] == "match" else 1


if __name__ == "__main__":
    sys.exit(main())
