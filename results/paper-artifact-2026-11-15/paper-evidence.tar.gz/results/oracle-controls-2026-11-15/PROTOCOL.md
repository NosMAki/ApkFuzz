# Gate-v3 local control check — protocol

Written before the device check. Use only the dedicated offline Android 10
`apkfuzz_fdroid29` emulator, wiped on launch, with Wi-Fi and mobile data
disabled. Run four hashed signed APK probes in order: baseline, inert
negative, known start-up-crash positive, baseline. `device_probe()` must
uninstall each APK, and F-Droid must be absent at the end.

Expected gate-v3 classes: baseline `launched_process_running`, inert
`launched_process_running` with the same resolved activity, crasher
`launched_crashed`, final baseline `launched_process_running`. Record fatal
exception evidence, provisional fingerprint, suspected manifest rejection,
ANR state, and cleanup. Any control mismatch or cleanup failure stops the
check. This is an oracle control rehearsal, not a mutant batch or a new
vulnerability finding.

- Matched baseline signed SHA-256:
  `f14653a6e7025f7176a75b5f5c3aff3e4b4472138818ce92588ca5be2419625c`.
- Inert enumerated flip 9157 signed SHA-256:
  `6b64e48acd7de3f8efc6b32f5e467d70a2619d58cc4e638338041160fe0c6cce`.
- Known start-up crasher `gen1_offline_ready:10433:iter15` signed SHA-256:
  `506406a45c167f034d0f3bd0f17bed2149c78944b3a0fe9adf1c2ba63505d29b`.

Use timeout 30 seconds per external command, settle 2 seconds, at most four
APK probes. Preserve JSON and emulator log. Stop and report if the emulator
does not boot within 300 seconds or the host cannot access adb/KVM. Shut the
emulator down after the check.
