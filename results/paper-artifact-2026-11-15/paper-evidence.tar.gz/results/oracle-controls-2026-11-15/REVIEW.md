# Gate-v3 local control check — review

The predeclared four-probe sequence **passed** on the local dedicated Android
10 emulator on 2026-11-15, 14:58:35–14:58:54 UTC. Emulator fingerprint:
`Android/sdk_phone_x86_64/generic_x86_64:10/QSR1.210820.001/7663313:userdebug/test-keys`.
AVD `apkfuzz_fdroid29`, serial `emulator-5562`, launched with `-no-snapshot
-wipe-data`; Wi-Fi and mobile data both read `0` before probing. The emulator
was shut down afterward and `adb devices -l` became empty.

| Control | Gate-v3 class | Raw package fatal blocks | Distinct fingerprints | Suspected manifest rejection | Cleanup |
| --- | --- | ---: | ---: | ---: | --- |
| Signed baseline, first | `launched_process_running` | 0 | 0 | 0 | Complete |
| Signed inert flip 9157 | `launched_process_running` | 0 | 0 | 0 | Complete |
| Signed known start-up crasher 10433/iter15 | `launched_crashed` | 15 | **1** | 15 blocks, same fingerprint | Complete |
| Signed baseline, last | `launched_process_running` | 0 | 0 | 0 | Complete |

All four hashes, signatures, and `aapt` package checks matched the protocol;
the healthy launches resolved to
`org.fdroid.fdroid/.views.main.MainActivity`. The positive control's fatal
was a `java.lang.RuntimeException` with a `SecurityException` in the block,
stack present, provisional fingerprint
`097cf92bf08b89ddcb19a78167a9be76ec179f72af7d170c4c5661727b37982b`.
It is a **manifest/permission-rejection control**, not an application defect.
The 15 records reflect a crash loop during **one clean installation**; they
are neither 15 independent crashes nor a three-run reproduction. No ANR was
induced, so real-device ANR extraction is not verified by this control check.

Raw report: [controls.json](controls.json), SHA-256
`6033a8c5b1e293c7f8067a832a8f1bd73acf07c0f25dc021b8579b8505fb96b0`.
Emulator log: [emulator.log](emulator.log), SHA-256
`bfa6b7bbf8258ef69c6ca648d1a8ac651e64c154e56b304acbd3296f2cd0a930`.
Driver: [check.py](check.py), SHA-256
`f8eb9f5e1edba8b08099e744b31aca98dbef373c521ccf0943f75da3ee33884a`.
The probe source used during this check had SHA-256
`583d93426e20f911716e0bb3d2974364fcfafa726b0c6145d5559da8b1f78335`.
After the control, the probe gained explicit distinct-fingerprint arrays;
the raw `controls.json` events already support the one-fingerprint count.
The classification rule and gate version remained unchanged; the new arrays
have focused synthetic tests, not a second device replay.

## AFL exception-signal control

In the same local checkout, `.venv/bin/python3` ran the deliberate
[`afl_signal_control.py`](afl_signal_control.py) exception through AFL++
`afl-showmap -t 10000 -m none`, with `PYTHON_AFL_SIGNAL=SIGUSR1`,
`AFL_SKIP_BIN_CHECK=1`, and
`AFL_I_DONT_CARE_ABOUT_MISSING_CRASHES=1`. `afl-showmap` exited **2**, reported
termination by **signal 10**, and captured **6 tuples**. This verifies that
the configured Python exception becomes an AFL signal outcome locally; it
does not validate Android crash detection or the earlier VM environment.
Raw [log](afl-signal.log), [map](afl-signal.map), and
[outcome](afl-signal.outcome.txt) are preserved. Their SHA-256 values are
`6f3eeb316d9d4e938656397c662d65e86c319d2f9091bb7763da09ea1584f54a`,
`a57ddb8f0cf0ea42786d067c9b63ecb8e7059a05ce42228ac278e4d36e266c17`,
and the script hash is
`8b8ff07c4655f363c7d564d6ff6f40ee1460cfb67bf32f672b7eb4b2f4064302`.
