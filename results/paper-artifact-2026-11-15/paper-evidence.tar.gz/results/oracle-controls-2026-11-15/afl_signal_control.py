"""Deliberate unhandled Python exception for the AFL signal control."""

import afl

afl.init()


def fail_after_traced_branches():
    for index in range(3):
        if index == 2:
            raise ValueError("controlled Python harness exception")


fail_after_traced_branches()
