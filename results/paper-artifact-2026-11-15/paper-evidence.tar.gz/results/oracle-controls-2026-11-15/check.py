#!/usr/bin/env python3
"""Run the predeclared gate-v3 controls; see PROTOCOL.md."""

import hashlib
import importlib.util
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("apkfuzz_probe", ROOT / "scripts/probe-android-runtime.py")
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)

BASELINE = (ROOT / "results/manifest-valid-onebit-local-30s-2026-11-12-10432-live-analysis/prepared-baseline.apk",
            "f14653a6e7025f7176a75b5f5c3aff3e4b4472138818ce92588ca5be2419625c")
INERT = (ROOT / "results/gen1-enumeration-2026-11-15-analysis/prepared/iter-000009157-g1.apk",
         "6b64e48acd7de3f8efc6b32f5e467d70a2619d58cc4e638338041160fe0c6cce")
CRASHER = (ROOT / "results/manifest-valid-onebit-local-10min-2026-11-12-10433-live-analysis/prepared/iter-000000015-g1.apk",
           "506406a45c167f034d0f3bd0f17bed2149c78944b3a0fe9adf1c2ba63505d29b")
SERIAL = "emulator-5562"


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    output = HERE / "controls.json"
    if output.exists():
        raise SystemExit("controls.json exists; preserve it")
    adb = shutil.which("adb") or "adb"
    aapt = probe.preflight.find_aapt()
    signer = shutil.which("apksigner") or "apksigner"
    report = {"schema_version": 1, "started_utc": now(),
              "launch_gate_version": probe.LAUNCH_GATE_VERSION,
              "serial": SERIAL, "timeout": 30, "settle": 2,
              "items": [], "status": "running"}

    def save():
        output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    save()
    expected_activity = None
    for name, (apk, expected_hash), expected in (
            ("baseline:first", BASELINE, "launched_process_running"),
            ("inert:flip9157", INERT, "launched_process_running"),
            ("known_crasher:10433:iter15", CRASHER, "launched_crashed"),
            ("baseline:last", BASELINE, "launched_process_running")):
        row = {"name": name, "apk": str(apk), "expected_sha256": expected_hash,
               "expected_class": expected, "started_utc": now()}
        report["items"].append(row)
        if not apk.is_file() or digest(apk) != expected_hash:
            row["error"] = "input_hash_mismatch"
            break
        signature = probe.run_command([signer, "verify", str(apk)], 30)
        metadata, package, activity = probe.package_metadata(aapt, apk, 30)
        row.update(signature=signature, aapt=metadata, package=package, activity=activity)
        if signature["status"] != "ok" or metadata["status"] != "ok" or not package:
            row["error"] = "offline_admission_failed"
            break
        runtime = probe.device_probe(adb, SERIAL, apk, package, activity, 30, 2,
                                     expected_activity)
        row.update(runtime=runtime, classification=runtime["classification"],
                   finished_utc=now())
        save()
        if (runtime["classification"] != expected or
                not (runtime.get("cleanup") or {}).get("complete")):
            row["error"] = "control_mismatch_or_cleanup_failed"
            break
        if name == "baseline:first":
            expected_activity = runtime["resolved_activity"]
    report["expected_activity"] = expected_activity
    report["finished_utc"] = now()
    report["status"] = "passed" if len(report["items"]) == 4 and all(
        "error" not in item for item in report["items"]) else "stopped"
    save()
    print(report["status"])
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
