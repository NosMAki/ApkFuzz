# Three-seed AFL input-generation check — protocol

Written before any arm on 2026-11-15. Use only the local authorized F-Droid
APK and pinned `manifest-axml-onebit` binary. Run three isolated 120-second
locked arms sequentially with AFL seeds **10441, 10442, 10443**. Use the same
runner, path-file input, custom mutator, and capture limit in all arms. Keep
each arm's raw log, config, source/input hashes, patches, AFL stats, and exact
captured candidates. A changed input or source hash, failed lock/mode check,
or nonzero exit invalidates that arm and stops interpretation.

Question: does this configured AFL route repeatedly produce bounded exact
mutants from the fixed seed? Per seed, report harness executions, queue
entries, saved *Python-harness* crashes, capture count, exact lineage and
offline APK preflight. Do not infer app coverage, Android admission, or defect
yield. Do not pool these results with the earlier seed 10435 run, which had a
different crash-signal configuration.

No emulator or application launch is part of this AFL-only batch. For a later
Android batch, the controls are the matched signed baseline, inert flips from
the 3,339-member negative class, and the known start-up crasher
`gen1_offline_ready:10433:iter15` as a gate positive control. That crash is
an expected invalid-input outcome, not an F-Droid defect. The new
[outcome oracle](../../docs/ORACLE.md) governs any future runtime claims.
One named inert control is enumerated flip 9157 (exact SHA-256
`6c3a57168f7fbffaafb7deeb55812aec753bf08cfd075209252883f9636e5f03`);
the named crasher's exact SHA-256 is
`a880e6f6d7dfc6efc39317a81c181e2a64dc0040ac8706976131ab555fb09306`.
Both historical control outcomes need a fresh gate-v3 check before reuse.

## Amendment after the first arm, before replacement

The first `seed-10441` arm started while the oracle code was still being
reviewed. A final probe edit changed a run-critical source hash during the
arm; the wrapper exited 1 with `source_drift=1`. Preserve that folder as an
invalid attempt and exclude its measurements. Repeat seed 10441 under the
final source snapshot in `seed-10441-rerun`, then run seeds 10442 and 10443.
Do not edit run-critical source or the mutator during these replacement arms.
