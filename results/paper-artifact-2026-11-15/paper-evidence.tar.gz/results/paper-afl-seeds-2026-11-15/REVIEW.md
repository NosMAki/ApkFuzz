# Three-seed AFL input-generation check — review

## Outcome

Three source-stable 120-second local locked `manifest-axml-onebit` arms
finished with exit 0. Each produced one new queue entry and preserved one
exact APK with verified patch provenance. All three exact APKs had valid ZIP
structure and a parseable structural manifest, but **all three failed the
original signature check**, as expected after mutation. No exact APK from
this batch was directly eligible for Android installation. No device,
LLMDroid, or F-Droid application behavior was tested in this batch.

| Seed | Harness executions | Final corpus | New queue entries / exact captures | ZIP / manifest | Original signature | Saved harness crashes / hangs |
| --- | ---: | ---: | ---: | --- | --- | ---: |
| 10441 (rerun) | 4,514 | 2 | 1 / 1 | valid / valid | invalid | 0 / 0 |
| 10442 | 4,482 | 2 | 1 / 1 | valid / valid | invalid | 0 / 0 |
| 10443 | 4,401 | 2 | 1 / 1 | valid / valid | invalid | 0 / 0 |

The selected exact SHA-256 values, in seed order, are
`301d6b711995dc7baf45de4714f0a70de2ceaeb78d117964bda3ef767851919c`,
`fc66a9231bc74c7caeab673a0bd953462723ddb4271a0a4a977517a21044e33f`,
and `4524f734ebba55277e8e3e291da162b1597c2b108c710b49acf908d84cc5e6c7`.
The per-seed `afl/candidates/manifest.json` and `candidate-preflight.json`
hold exact paths, hashes, and rejection reasons. `research_ready=1` in the
capture manifest means provenance-ready for offline research; it does **not**
override the signature failure in runtime preflight.

## Configuration and integrity

Protocol: [PROTOCOL.md](PROTOCOL.md). Local origin SHA-256
`1dfce4269081693f10350dbabd26991a59d7c2bb81f870de54e5b113f4785b7a`;
locked mutator binary SHA-256
`ba42388c6fb50d7ce6917dc863b79b2047c14547b631f852fd5bd5093bb56496`.
All three `input-sha256.txt` files are identical; all three
`source-sha256.txt` files are identical (file SHA-256
`0abde15d39b7eaee509e4e10d6f64d6d499091445e6d3cc41f6a8a64f09f7e11`).
Each `outcome.txt` records `source_drift=0`, `input_drift=0`, and
`final_exit_code=0`. `config.txt` records Python 3.12.3, AFL++ 4.09c,
`PYTHON_AFL_SIGNAL=SIGUSR1`, the piped core reporter, and the exact command
settings. The origin APK, binary, and run outputs remained local; no VM or
network-facing experiment was started.

The first `seed-10441` folder is an **excluded attempt**: an oracle source edit
occurred during that arm. Its wrapper recorded `source_drift=1` and
`final_exit_code=1`. It is preserved, not pooled. The final code later gained
bounded raw crash/ANR log evidence; the three valid arms share the exact
pre-final source snapshot recorded in their own hash files. That later probe
change does not alter their archived AFL outputs.

## Interpretation

The 13,397 executions and 2.94% AFL bitmap occupancy per arm describe the
Python ZIP/path-file harness only. The zero saved crashes say nothing about
F-Droid's behavior. The three seeds show repeatable generation of a valid
ZIP/manifest **exact input** and repeatable signature rejection of that exact
input under this short arm. They do not estimate the installable rate of
separately re-signed mutants, multi-generation yield, parser divergence, or
security defects. The exhaustive first-generation enumeration is the stronger
evidence for the finite one-bit origin space.

The named future Android controls are an inert flip (`9157`; exact SHA-256
`6c3a57168f7fbffaafb7deeb55812aec753bf08cfd075209252883f9636e5f03`)
and known start-up crasher (`gen1_offline_ready:10433:iter15`; exact SHA-256
`a880e6f6d7dfc6efc39317a81c181e2a64dc0040ac8706976131ab555fb09306`),
alongside a matched signed baseline. They were **not run** in this AFL-only
batch. Their historical gate-v2 classifications must be checked under gate
v3 before a new Android batch.
